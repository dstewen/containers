import express from "express";
import { createServer } from "http";
import { WebSocketServer } from "ws";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { SparkRegistry } from "./sparks/SparkRegistry.js";
import { resolveFrontendDir, FRONTEND_MISSING_MESSAGE } from "./frontendDir.js";
import { SparkMonitor } from "./sparks/SparkMonitor.js";
import { collectionWasSuccessful } from "./collectors/SystemCollector.js";
import { sshExec } from "./collectors/ssh.js";
import { comfyCancelJob } from "./collectors/comfyActions.js";
import {
  validateSparkTarget,
  normalizeSshPort,
  createRateLimiter,
  assertAllowedTarget,
  validateDecodeBudget,
  validatePrefillBudget,
} from "./validate.js";
import { authStatus, authorizeUpgrade, createAuthMiddleware, createHostGuardMiddleware, isLoopbackBind, setTailscaleName } from "./auth.js";
import { inspectHealth } from "./health.js";
import { getSettings, updateSettings, loadSettings } from "./settings.js";
import { broadcastForLanIp, effectiveMac, normalizeMac, sendWol } from "./wol.js";
import { remoteShutdownCommand, spawnLocalShutdown } from "./shutdown.js";
import {
  decodeBenchManager,
  DECODE_BENCH_DEFAULTS,
  normalizeConcurrencies,
} from "./collectors/DecodeBench.js";
import {
  prefillBenchManager,
  PREFILL_BENCH_DEFAULTS,
  normalizeContextSizes,
} from "./collectors/PrefillBench.js";
import {
  qualityBenchManager,
  QUALITY_BENCH_DEFAULTS,
  normalizeQualityOptions,
} from "./collectors/QualityBench.js";
import { showcaseManager } from "./collectors/ShowcaseManager.js";
import { llmProbeHost } from "./collectors/llmHost.js";
import { onceClose, resolveLlmHttpTarget } from "./collectors/llmTunnel.js";
import { formatLlmBaseUrl, parseLlmTargetInput } from "../src/shared/llmTarget.js";
import { llmDaily } from "./collectors/LlmDaily.js";
import {
  createLlmTokenRuntime,
  registerLlmTokenTotalsRoute,
  llmTokenLedger,
} from "./llmtokens/LlmTokenRuntime.js";
import { closeLlmStreamAgent } from "./collectors/LlmStreaming.js";
import { compareSemver, getLatestRelease } from "./collectors/HermesReleases.js";
import { FLEET_ENERGY_JSON_PATH, FLEET_ENERGY_MONTHLY_JSON_PATH } from "./config.js";
import { FleetEnergyTracker } from "./energy/FleetEnergyTracker.js";
import { EventLog } from "./events/EventLog.js";
import { GpuHistory, deviceReadings } from "./metrics/GpuHistory.js";
import { LauncherStore } from "./llmlaunch/LauncherStore.js";
import { LauncherManager } from "./llmlaunch/LauncherManager.js";
import { ToolEvalStore } from "./tooleval/ToolEvalStore.js";
import { ToolEvalManager } from "./tooleval/ToolEvalManager.js";
import { registerToolEvalRoutes } from "./tooleval/routes.js";
import { benchEvent } from "./events/eventFormat.js";
import {
  createFleetEnergyRuntime,
  registerFleetEnergyRoute,
} from "./energy/FleetEnergyRuntime.js";
import { testSparkConnectivity } from "./connectivity.js";
import { TailscaleProbe } from "./collectors/TailscaleProbe.js";
import { inspectStartupPreflight, logStartupPreflight } from "./startupPreflight.js";
import { PROMETHEUS_CONTENT_TYPE, metricsEntries, renderPrometheusMetrics } from "./prometheus.js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = path.resolve(__dirname, "..");

// Default to loopback. A non-loopback bind without SPARKDASH_TOKEN stays OPEN —
// anyone who can reach the port can mutate settings and power units — unless
// SPARKDASH_ALLOW_OPEN_REMOTE=0, which makes startup fail closed instead. Prefer
// SPARKDASH_TOKEN, an SSH tunnel, an authenticated reverse proxy, or Tailscale
// Serve (docs/REMOTE-ACCESS.md).
const BIND_HOST = process.env.BIND_HOST || "127.0.0.1";
const PORT = parseInt(process.env.PORT || "5555", 10);
const LLM_PORT = parseInt(process.env.LLM_PORT || "8888", 10);
const COMFY_PORT = parseInt(process.env.COMFY_PORT || "8188", 10);

/** Per-spark LLM HTTP port (1–65535), else env default. */
function resolveLlmPort(sparkOrPort) {
  if (sparkOrPort && typeof sparkOrPort === "object") {
    // Prefer llmPorts array, fall back to legacy llmPort
    const ports = sparkOrPort.llmPorts;
    if (Array.isArray(ports) && ports.length > 0) {
      const n = ports[0];
      if (Number.isInteger(n) && n >= 1 && n <= 65535) return n;
    }
    const raw = sparkOrPort.llmPort;
    const n = typeof raw === "string" ? parseInt(raw, 10) : Number(raw);
    if (Number.isInteger(n) && n >= 1 && n <= 65535) return n;
    return LLM_PORT;
  }
  const raw = sparkOrPort;
  const n = typeof raw === "string" ? parseInt(raw, 10) : Number(raw);
  if (Number.isInteger(n) && n >= 1 && n <= 65535) return n;
  return LLM_PORT;
}

/** Per-spark ComfyUI HTTP port (1–65535), else env default 8188. */
function resolveComfyPort(sparkOrPort) {
  if (sparkOrPort && typeof sparkOrPort === "object") {
    const raw = sparkOrPort.comfyPort;
    const n = typeof raw === "string" ? parseInt(raw, 10) : Number(raw);
    if (Number.isInteger(n) && n >= 1 && n <= 65535) return n;
    return COMFY_PORT;
  }
  const raw = sparkOrPort;
  const n = typeof raw === "string" ? parseInt(raw, 10) : Number(raw);
  if (Number.isInteger(n) && n >= 1 && n <= 65535) return n;
  return COMFY_PORT;
}

/** Optional Bearer token for a Spark LLM port (from encrypted secrets). */
function resolveLlmApiKey(spark, port) {
  const keys = spark?.llmApiKeys;
  if (!keys || typeof keys !== "object") return null;
  const raw = keys[String(port)] ?? keys[port];
  const key = raw != null ? String(raw).trim() : "";
  return key || null;
}

/**
 * Local Spark LLM port, or an on-demand remote host (HTTPS Tailscale, etc.).
 * Custom `host` skips the configured-port allowlist and SSH tunnel.
 *
 * @param {object} spark
 * @param {number[]} configuredPorts
 * @param {object} body
 */
async function benchHttpTarget(spark, configuredPorts, body) {
  const hostRaw = body?.host != null ? String(body.host).trim() : "";
  if (hostRaw) {
    const parsed = parseLlmTargetInput(hostRaw, body?.port, body?.tls);
    const extra = extraBenchmarkHosts();
    if (!extra.has(parsed.host)) {
      const err = new Error(
        `Remote benchmark host ${parsed.host} is not allowlisted. Add it to SPARKDASH_BENCH_HOSTS or use a saved Spark LLM target.`
      );
      err.status = 403;
      throw err;
    }
    await assertAllowedTarget(parsed.host, extra);
    return {
      port: parsed.port,
      host: parsed.host,
      tls: parsed.tls,
      custom: true,
      apiKey: null,
      resolveTarget: async ({ onStatus }) => {
        onStatus?.(`Reaching ${formatLlmBaseUrl(parsed)}…`);
        return {
          host: parsed.host,
          port: parsed.port,
          tls: parsed.tls,
          via: "direct",
          close: onceClose(() => {}),
        };
      },
    };
  }

  let port = body?.port != null ? Number(body.port) : configuredPorts[0];
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    const err = new Error("Invalid port");
    err.status = 400;
    throw err;
  }
  if (!configuredPorts.includes(port)) {
    const err = new Error("port is not configured for this Spark");
    err.status = 400;
    throw err;
  }
  return {
    port,
    host: null,
    tls: false,
    custom: false,
    apiKey: resolveLlmApiKey(spark, port),
    resolveTarget: ({ onStatus, signal }) =>
      resolveLlmHttpTarget(spark, port, {
        apiKey: resolveLlmApiKey(spark, port),
        onStatus,
        signal,
      }),
  };
}

function extraBenchmarkHosts() {
  return new Set(
    String(process.env.SPARKDASH_BENCH_HOSTS || "")
      .split(",")
      .map((value) => value.trim())
      .filter(Boolean)
  );
}

function fleetTargetHosts() {
  const hosts = new Set();
  for (const spark of registry.sparks) {
    if (spark.lanIp) hosts.add(spark.lanIp);
    if (spark.ssh?.host) hosts.add(spark.ssh.host);
  }
  return hosts;
}

async function assertFleetTarget(body) {
  const validationError = validateSparkTarget(body);
  if (validationError) {
    const err = new Error(validationError);
    err.status = 400;
    throw err;
  }
  const sshHost = body?.ssh?.host || "";
  const lanIp = body?.lanIp || "";
  const target = sshHost || lanIp;
  const allowed = fleetTargetHosts();
  if (target) allowed.add(target);
  if (lanIp) allowed.add(lanIp);
  if (target) await assertAllowedTarget(target, allowed);
  if (lanIp && lanIp !== target) await assertAllowedTarget(lanIp, allowed);
}

function principalKey(req) {
  return req.principal?.id || clientKey(req);
}

function rejectLimited(res, message) {
  return res.status(429).json({ error: message });
}

const allowTest = createRateLimiter(20, 60_000);
const allowDestructive = createRateLimiter(10, 60_000);
/** Decode + prefill starts per principal (retries that 400/409 do not count). */
const allowBench = createRateLimiter(20, 60_000);
const allowGlobalDestructive = createRateLimiter(30, 60_000);
/** Anti double-submit only; per-Spark mutex + MAX_ACTIVE_BENCH_JOBS cap load. */
const benchCooldown = createRateLimiter(1, 3_000);
const MAX_ACTIVE_BENCH_JOBS = 2;

/** Running decode + prefill + quality jobs across all Sparks. */
function activeBenchJobCount() {
  return (
    decodeBenchManager.activeCount() +
    prefillBenchManager.activeCount() +
    qualityBenchManager.activeCount()
  );
}

/** Consume bench-start quota only when every limiter would allow it. */
function consumeBenchStartQuota(req, res) {
  // Re-check the global cap here: routes check it up front, then await DNS /
  // target resolution, so two concurrent requests could both have passed. This
  // runs synchronously right before the manager's start(), closing that window.
  if (activeBenchJobCount() >= MAX_ACTIVE_BENCH_JOBS) {
    res.status(429).json({ error: "Global active benchmark cap reached; wait for a job to finish" });
    return false;
  }
  const key = principalKey(req);
  const ip = clientKey(req);
  if (!allowBench(key, true)) {
    rejectLimited(res, "Too many benchmark requests; try again shortly");
    return false;
  }
  if (!benchCooldown(key, true)) {
    rejectLimited(res, "Benchmark cooldown is active; wait before starting another job");
    return false;
  }
  if (!allowGlobalDestructive(ip, true)) {
    rejectLimited(res, "Too many requests; try again shortly");
    return false;
  }
  allowBench(key);
  benchCooldown(key);
  allowGlobalDestructive(ip);
  return true;
}

// ─── Spark registry ──────────────────────────────────────
const registry = new SparkRegistry();

const fleetEnergyTracker = new FleetEnergyTracker({
  nodeIds: registry.sparkIds,
  filePath: FLEET_ENERGY_JSON_PATH,
  monthlyFilePath: FLEET_ENERGY_MONTHLY_JSON_PATH,
});

// ─── Fleet event log ─────────────────────────────────────
const eventLog = new EventLog({
  file: process.env.EVENTS_JSON_PATH || path.join(ROOT, "config", "events.json"),
  // The Activity page browses history, so keep far more than the Overview card shows.
  max: 2000,
});

// ─── GPU history (so a fresh page can draw the last hours at once) ─────
const gpuHistory = new GpuHistory({
  file: process.env.GPU_HISTORY_JSON_PATH || path.join(ROOT, "config", "gpu-history.json"),
});
const GPU_HISTORY_SAMPLE_MS = 2000;
function sampleGpuHistory() {
  try {
    for (const snap of orderedSnapshots()) {
      const gpu = snap?.metrics?.gpu;
      // Require a real collection: a default/failed GPU result would record a fabricated 0 C / 0 %.
      if (!snap?.online || !gpu || !collectionWasSuccessful(gpu)) continue;
      const draw = gpu.power?.draw;
      const limit = gpu.power?.limit;
      const powerPct = Number.isFinite(draw) && Number.isFinite(limit) && limit > 0 ? Math.min(100, (draw / limit) * 100) : null;
      gpuHistory.record(snap.id, Date.now(), gpu.usage, gpu.temperature, powerPct, deviceReadings(gpu.gpus));
    }
  } catch {
    /* sampling must never break the server */
  }
}
const gpuHistoryTimer = setInterval(sampleGpuHistory, GPU_HISTORY_SAMPLE_MS);
gpuHistoryTimer.unref?.();
gpuHistory.start();

/** Record an event; never throws (callers sit in poll loops and routes). */
function recordEvent(event) {
  try {
    const name = event.sparkName ?? registry.getSpark(event.sparkId)?.name ?? event.sparkId ?? null;
    return eventLog.record({ ...event, sparkName: name });
  } catch {
    return null;
  }
}

for (const [mgr] of [[decodeBenchManager], [prefillBenchManager], [qualityBenchManager]]) {
  mgr.setEventSink((kind, job) => {
    const name = registry.getSpark(job.sparkId)?.name || job.sparkId;
    const ev = benchEvent(kind, job, name);
    if (ev) recordEvent({ ...ev, sparkId: job.sparkId, sparkName: name });
  });
}

// ─── User-registered LLM launchers (start.sh / stop.sh) ──
const launcherStore = new LauncherStore({
  file: process.env.LLM_LAUNCHERS_JSON_PATH || path.join(ROOT, "config", "llm-launchers.json"),
});
const launcherManager = new LauncherManager({
  store: launcherStore,
  onEvent: (event) => recordEvent(event),
});
const allowLaunch = createRateLimiter(20, 60_000);
/** Launcher status reads and attach each cost an SSH exec. */
const allowLaunchProbe = createRateLimiter(60, 60_000);
const LAUNCHER_STATUS_TTL_MS = 10_000;
/** @type {Map<string, { at: number, sig: string, value?: unknown, pending?: Promise<unknown> }>} */
const launcherStatusCache = new Map();

/** Launcher statuses per Spark: cached ~10 s, concurrent callers share one SSH exec. */
async function cachedLauncherStatuses(spark, launchers) {
  const latest = launcherManager.latestJob(spark.id);
  const sig = JSON.stringify([launchers.map((l) => l.id ?? l.name), latest?.id ?? null]);
  const busy = Boolean(launcherManager.activeJob(spark.id));
  const hit = launcherStatusCache.get(spark.id);
  if (hit && hit.sig === sig && !busy) {
    if (hit.pending) return hit.pending;
    if (Date.now() - hit.at < LAUNCHER_STATUS_TTL_MS) return hit.value;
  }
  const entry = { at: Date.now(), sig };
  const pending = Promise.resolve(launcherManager.statuses(spark, launchers)).then(
    (value) => {
      entry.value = value;
      entry.at = Date.now();
      delete entry.pending;
      return value;
    },
    (err) => {
      if (launcherStatusCache.get(spark.id) === entry) launcherStatusCache.delete(spark.id);
      throw err;
    }
  );
  entry.pending = pending;
  launcherStatusCache.set(spark.id, entry);
  return pending;
}

// ─── Tool Eval (tool-eval-bench on a Spark) ──────────────
const toolEvalStore = new ToolEvalStore({
  file: process.env.TOOL_EVAL_RUNS_PATH || path.join(ROOT, "config", "tool-eval-runs.json"),
  resultsDir: process.env.TOOL_EVAL_RESULTS_DIR || path.join(ROOT, "config", "tool-eval-results"),
});
const toolEvalManager = new ToolEvalManager({
  store: toolEvalStore,
  onEvent: (event) => recordEvent(event),
});
const allowToolEval = createRateLimiter(30, 60_000);

// ─── Monitor map ─────────────────────────────────────────
const monitors = new Map();

// ─── Start monitor for a Spark ───────────────────────────
function startMonitor(spark) {
  if (monitors.has(spark.id)) return;
  const monitor = new SparkMonitor(spark, {
    onWolMac: (id, mac) => {
      const updated = registry.noteDetectedMac(id, mac);
      if (updated) {
        const mon = monitors.get(id);
        if (mon) mon.updateConfig(registry.getSpark(id));
      }
    },
    // Hermes check / update results must not wait for the next broadcast tick.
    onHermesChange: () => forceBroadcast(),
    onEvent: recordEvent,
    // Worker derived label: resolve a head id to its live LLM model id.
    // Returns null when the head is unknown/offline/model-less so workers
    // never display a stale model. Display-only; never writes to config.
    resolveHeadModelId: (headId) => monitors.get(headId)?.headLlmModelId() ?? null,
    // Settings → Poll interval drives the collectors, not just the broadcast.
    pollIntervalMs: getSettings().pollIntervalMs,
  });
  monitors.set(spark.id, monitor);
  monitor.start();
}

// ─── Stop and remove monitor for a Spark ─────────────────
function stopMonitor(id) {
  const monitor = monitors.get(id);
  if (monitor) {
    monitor.stop();
    monitors.delete(id);
  }
}

// ─── Start all monitors from registry ───────────────────
function startAllMonitors() {
  for (const spark of registry.sparks) {
    startMonitor(spark);
  }
}

/** Snapshots in registry tab order (not Map insertion order). */
function orderedSnapshots() {
  return registry.sparkIds
    .map((id) => monitors.get(id))
    .filter(Boolean)
    .map((m) => m.snapshot());
}

const fleetEnergyRuntime = createFleetEnergyRuntime({
  tracker: fleetEnergyTracker,
  orderedSnapshots,
  monitors,
});

// Cumulative prompt/generated token totals per model (per-UTC-day buckets for range queries).
const llmTokenRuntime = createLlmTokenRuntime({ ledger: llmTokenLedger, orderedSnapshots });

// ─── Express app ─────────────────────────────────────────
const app = express();
const server = createServer(app);

app.use(express.json());
// Registered ahead of the auth middleware: a remote browser holding no token
// (or a stale one) must still be able to learn that it needs one.
app.get("/api/auth/status", createHostGuardMiddleware(), (req, res) => {
  res.json(authStatus(req));
});
app.use(createAuthMiddleware());

/** Fleet event log, newest first. Query: limit, sparkId, sinceId. */
app.get("/api/events", (req, res) => {
  const limit = Number.parseInt(String(req.query.limit ?? ""), 10);
  const sinceId = Number.parseInt(String(req.query.sinceId ?? ""), 10);
  const beforeId = Number.parseInt(String(req.query.beforeId ?? ""), 10);
  const sparkId = typeof req.query.sparkId === "string" && req.query.sparkId ? req.query.sparkId : undefined;
  res.json({
    events: eventLog.list({
      limit: Number.isFinite(limit) ? limit : 50,
      sparkId,
      sinceId: Number.isFinite(sinceId) ? sinceId : undefined,
      beforeId: Number.isFinite(beforeId) ? beforeId : undefined,
    }),
    // Lets the page know whether "load older" can return anything.
    oldestId: eventLog.oldestId?.() ?? null,
  });
});

/** Clear Activity history. Query: olderThanMs (omit to delete everything). */
app.delete("/api/events", (req, res) => {
  const raw = req.query.olderThanMs;
  const olderThanMs = raw == null || raw === "" ? undefined : Number(raw);
  if (olderThanMs !== undefined && (!Number.isFinite(olderThanMs) || olderThanMs <= 0)) {
    return res.status(400).json({ error: "olderThanMs must be a positive number" });
  }
  res.json({ removed: eventLog.clear({ olderThanMs }) });
});

/**
 * In-app restart. Only offered inside the Docker container, where the node --watch
 * supervisor is PID 1 and the compose file's `restart: always` brings the container
 * back; anywhere else exiting would simply stop the server.
 */
const restartSupported = () => {
  try {
    if (!fs.existsSync("/.dockerenv")) return false;
    // The container may share the host PID namespace, so look for the supervisor by command line.
    return fs.readFileSync(`/proc/${process.ppid}/cmdline`, "utf8").split("\0").includes("--watch");
  } catch {
    return false;
  }
};

app.get("/api/restart", (_req, res) => {
  res.json({ available: restartSupported() });
});

app.post("/api/restart", (_req, res) => {
  if (!restartSupported()) {
    return res.status(409).json({ error: "Restart is only available when sparkDash runs in Docker with restart: always" });
  }
  console.log("[sparkDash] restart requested from the UI");
  res.json({ restarting: true });
  // Stopping the supervisor makes the child shut down gracefully (SIGTERM) and
  // lets Docker's restart policy start a fresh container.
  res.on("finish", () => setTimeout(() => process.kill(process.ppid, "SIGTERM"), 200).unref());
});

app.get("/api/health", (_req, res) => {
  res.json(inspectHealth(process.env.BIND_HOST || "127.0.0.1"));
});

function clientKey(req) {
  return req.ip || req.socket?.remoteAddress || "unknown";
}

// ─── REST API ────────────────────────────────────────────
registerFleetEnergyRoute(app, fleetEnergyTracker);
registerLlmTokenTotalsRoute(app, llmTokenLedger);

// Never return SSH passwords in any response
app.get("/api/sparks", (_req, res) => {
  res.json({ sparks: registry.publicSparks });
});

// Ephemeral connectivity test — does not persist or start a monitor
app.post("/api/sparks/test", async (req, res) => {
  try {
    if (!allowTest(principalKey(req)) || !allowGlobalDestructive(clientKey(req))) {
      return rejectLimited(res, "Too many test requests; try again shortly");
    }
    const body = req.body || {};
    const validationError = validateSparkTarget(body);
    if (validationError) {
      return res.status(400).json({ error: validationError });
    }
    const spark = {
      id: body.id || "ephemeral-test",
      name: body.name || "test",
      lanIp: body.lanIp || "",
      llmHost: body.llmHost,
      cx7Ip: body.cx7Ip || null,
      platform: body.platform === "windows" ? "windows" : body.platform === "darwin" ? "darwin" : "linux",
      kind: body.platform === "windows" ? "host" : body.kind,
      isLocal: Boolean(body.isLocal),
      role: body.role,
      workerNode: Boolean(body.workerNode),
      llmMonitoring: body.llmMonitoring,
      llmPort: resolveLlmPort(body),
      comfyPort: resolveComfyPort(body),
      comfyMonitoring: Boolean(body.comfyMonitoring),
      hermesMonitoring: Boolean(body.hermesMonitoring),
      tailscaleMonitoring: Boolean(body.tailscaleMonitoring),
      ssh: {
        host: body.ssh?.host || body.lanIp || "",
        user: body.ssh?.user || "root",
        auth: body.ssh?.auth === "pass" ? "pass" : "key",
        password: body.ssh?.password,
        port: normalizeSshPort(body.ssh?.port) ?? 22,
      },
    };
    if (!spark.isLocal && !spark.lanIp && !spark.ssh.host) {
      return res.status(400).json({ error: "lanIp or ssh.host required" });
    }
    const llmPort = resolveLlmPort(spark);
    const comfyPort = resolveComfyPort(spark);
    const result = await testSparkConnectivity(spark, { llmPort, comfyPort });
    const byId = Object.fromEntries(result.capabilities.map((capability) => [capability.id, capability]));
    res.json({
      id: spark.id,
      capabilities: result.capabilities,
      ssh: { ok: byId.host.status === "pass", message: byId.host.message },
      llm: { ok: byId.llm.status !== "fail", message: byId.llm.message, skipped: byId.llm.status === "skipped" },
      comfy: { ok: byId.comfy.status !== "fail", message: byId.comfy.message, skipped: byId.comfy.status === "skipped" },
      ok: result.ok,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/sparks", (req, res) => {
  try {
    const validationError = validateSparkTarget(req.body || {});
    if (validationError) {
      return res.status(400).json({ error: validationError });
    }
    const spark = registry.addSpark(req.body);
    fleetEnergyTracker.invalidateMembership(registry.sparkIds);
    startMonitor(spark);
    recordEvent({
      type: "spark.added",
      severity: "info",
      sparkId: spark.id,
      sparkName: spark.name,
      message: `${spark.name || spark.id} was added`,
    });
    res.json({ success: true, spark: registry.toPublic(spark) });
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

app.patch("/api/sparks/:id", (req, res) => {
  try {
    const body = req.body || {};
    // Only validate host fields if they are being updated
    if (
      body.lanIp != null ||
      body.llmHost != null ||
      body.isLocal != null ||
      body.ssh?.host != null ||
      body.ssh?.user != null ||
      body.ssh?.port != null
    ) {
      const existing = registry.getSpark(req.params.id);
      if (!existing) return res.status(404).json({ error: "Spark not found" });
      const merged = {
        isLocal: body.isLocal ?? existing.isLocal,
        lanIp: body.lanIp ?? existing.lanIp,
        llmHost: body.llmHost ?? existing.llmHost,
        ssh: { ...existing.ssh, ...(body.ssh || {}) },
      };
      const validationError = validateSparkTarget(merged);
      if (validationError) {
        return res.status(400).json({ error: validationError });
      }
    }

    // Password-only update: hot-apply without full monitor restart
    const keys = Object.keys(body).filter((k) => k !== "ssh");
    const sshKeys = body.ssh ? Object.keys(body.ssh) : [];
    const passwordOnly =
      keys.length === 0 &&
      sshKeys.length > 0 &&
      sshKeys.every((k) => k === "password");

    if (passwordOnly && body.ssh?.password) {
      const spark = registry.setPassword(req.params.id, body.ssh.password);
      const mon = monitors.get(req.params.id);
      if (mon) mon.updateConfig(registry.getSpark(req.params.id));
      return res.json({ success: true, spark, hasPassword: true });
    }

    // LLM API keys: an llmPorts change is the second bypass besides out-of-band
    // sparks.json writes. patchSpark() arms the reconcile on the llmPorts
    // own-property (any shape — [] and the legacy scalar are applied by the
    // normalizer too) and syncs against the post-normalize ports.
    const { spark } = registry.patchSpark(req.params.id, body);
    // Restart monitor so collectors pick up host/auth/isLocal changes
    stopMonitor(req.params.id);
    startMonitor(spark);
    res.json({
      success: true,
      spark: registry.toPublic(spark),
      hasPassword: registry.hasPassword(req.params.id),
    });
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

app.delete("/api/sparks/:id", (req, res) => {
  try {
    const removed = registry.removeSpark(req.params.id);
    if (!removed) return res.status(404).json({ error: "Spark not found" });
    fleetEnergyTracker.invalidateMembership(registry.sparkIds);
    stopMonitor(req.params.id);
    launcherManager.removeSpark(req.params.id);
    launcherStatusCache.delete(req.params.id);
    gpuHistory.remove(req.params.id);
    toolEvalManager.removeSpark(req.params.id);
    recordEvent({
      type: "spark.removed",
      severity: "info",
      sparkId: req.params.id,
      sparkName: removed?.name || req.params.id,
      message: `${removed?.name || req.params.id} was removed`,
    });
    res.json({ success: true, removed });
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

// Reorder Sparks in the tab bar (persisted to sparks.json)
app.put("/api/sparks/order", (req, res) => {
  try {
    const order = req.body?.order;
    if (!Array.isArray(order)) {
      return res.status(400).json({ error: "body.order must be an array of spark ids" });
    }
    const sparks = registry.reorderSparks(order);
    res.json({ success: true, sparks });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ─── Global settings ──────────────────────────────────────
app.get("/api/settings", (_req, res) => {
  res.json(getSettings());
});

app.put("/api/settings", (req, res) => {
  try {
    const patch = req.body || {};
    const newSettings = updateSettings(patch);
    // Poll interval changed: re-arm the running monitors' collector timers
    // (in place — no restart, no lost backoff state) and the broadcast timer.
    if (patch.pollIntervalMs != null) {
      for (const monitor of monitors.values()) {
        monitor.setPollInterval(newSettings.pollIntervalMs);
      }
      restartBroadcast();
    }
    res.json(newSettings);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Recent GPU utilization / temperature / power % for one Spark (parallel arrays), newest last.
app.get("/api/sparks/:id/gpu-history", (req, res) => {
  if (!registry.getSpark(req.params.id)) return res.status(404).json({ error: "Spark not found" });
  const windowMs = Math.min(8 * 3600_000, Math.max(60_000, Number(req.query.windowMs) || 8 * 3600_000));
  res.json(gpuHistory.get(req.params.id, Date.now() - windowMs));
});

app.get("/api/sparks/:id/metrics", (req, res) => {
  const monitor = monitors.get(req.params.id);
  if (!monitor) return res.status(404).json({ error: "Spark not found" });
  res.json(monitor.snapshot());
});

// Test SSH + LLM connectivity for a registered Spark.
// Optional body.ssh.password is ALWAYS saved (even if the host is down).
app.post("/api/sparks/:id/test", async (req, res) => {
  if (!allowTest(principalKey(req)) || !allowGlobalDestructive(clientKey(req))) {
    return rejectLimited(res, "Too many test requests; try again shortly");
  }
  try {
    const body = req.body || {};
    const incomingPassword = body.ssh?.password ?? body.password;
    // Persist password first — does not require host reachability
    if (incomingPassword != null && incomingPassword !== "") {
      registry.setPassword(req.params.id, incomingPassword);
    }

    const spark = registry.getSpark(req.params.id);
    if (!spark) return res.status(404).json({ error: "Spark not found" });

    const result = await testSparkConnectivity(spark, {
      llmPort: resolveLlmPort(spark),
      comfyPort: resolveComfyPort(spark),
    });
    const byId = Object.fromEntries(result.capabilities.map((capability) => [capability.id, capability]));
    res.json({
      id: req.params.id,
      capabilities: result.capabilities,
      ssh: { ok: byId.host.status === "pass", message: byId.host.message },
      llm: { ok: byId.llm.status !== "fail", message: byId.llm.message, skipped: byId.llm.status === "skipped" },
      comfy: { ok: byId.comfy.status !== "fail", message: byId.comfy.message, skipped: byId.comfy.status === "skipped" },
      ok: result.ok,
      hasPassword: registry.hasPassword(req.params.id),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

registerToolEvalRoutes(app, {
  registry,
  manager: toolEvalManager,
  store: toolEvalStore,
  allowRun: allowToolEval,
  principalKey,
  rejectLimited,
});

// ─── LLM launchers: register a directory with start.sh / stop.sh and run it ───
// The API only ever executes the registered start/stop script names inside the
// registered directory (see llmlaunch/validate.js); it never runs a free-form command.

function launcherContext(req, res) {
  const spark = registry.getSpark(req.params.id);
  if (!spark) {
    res.status(404).json({ error: "Spark not found" });
    return null;
  }
  if (spark.platform === "windows") {
    // Launchers run bash start/stop scripts; not supported on Windows PCs (yet).
    res.status(400).json({ error: "Starting and stopping models from sparkDash is not supported on Windows PCs" });
    return null;
  }
  return spark;
}

app.get("/api/sparks/:id/llm-launchers", async (req, res) => {
  const spark = launcherContext(req, res);
  if (!spark) return;
  const launchers = launcherStore.list(spark.id);
  const body = {
    launchers,
    job: launcherManager.latestJob(spark.id) ? launcherManager.summary(launcherManager.latestJob(spark.id)) : null,
  };
  // Status needs one SSH round trip, so it is opt-in (the panel asks once on open and after each job).
  if (req.query.status === "1") {
    if (!allowLaunchProbe(principalKey(req))) {
      return rejectLimited(res, "Too many status requests; try again shortly");
    }
    body.statuses = await cachedLauncherStatuses(spark, launchers);
  }
  res.json(body);
});

app.post("/api/sparks/:id/llm-launchers", (req, res) => {
  const spark = launcherContext(req, res);
  if (!spark) return;
  launcherStatusCache.delete(spark.id);
  const result = launcherStore.add(spark.id, req.body);
  if (!result.ok) return res.status(400).json({ error: result.error });
  res.status(201).json({ launcher: result.launcher });
});

app.put("/api/sparks/:id/llm-launchers/:lid", async (req, res) => {
  const spark = launcherContext(req, res);
  if (!spark) return;
  launcherStatusCache.delete(spark.id);
  const result = await launcherManager.updateLauncher(spark, req.params.lid, req.body);
  if (!result.ok) return res.status(result.notFound ? 404 : result.conflict ? 409 : 400).json({ error: result.error });
  res.json({ launcher: result.launcher });
});

app.delete("/api/sparks/:id/llm-launchers/jobs/active", (req, res) => {
  const spark = launcherContext(req, res);
  if (!spark) return;
  res.json({ success: launcherManager.cancel(spark.id) });
});

app.delete("/api/sparks/:id/llm-launchers/:lid", async (req, res) => {
  const spark = launcherContext(req, res);
  if (!spark) return;
  const active = launcherManager.activeJob(spark.id);
  if (active && active.launcherId === req.params.lid) {
    return res.status(409).json({ error: "A job is running for this model. Cancel it first." });
  }
  launcherStatusCache.delete(spark.id);
  const removed = await launcherManager.removeLauncher(spark, req.params.lid);
  if (!removed.ok) return res.status(removed.notFound ? 404 : removed.conflict ? 409 : 400).json({ error: removed.error });
  res.json({ success: true });
});

app.get("/api/sparks/:id/llm-launchers/jobs/:jobId", (req, res) => {
  const spark = launcherContext(req, res);
  if (!spark) return;
  const since = Number.parseInt(String(req.query.since ?? "0"), 10);
  const read = launcherManager.readJob(spark.id, req.params.jobId, Number.isFinite(since) ? since : 0);
  if (!read) return res.status(404).json({ error: "Job not found (it may have been replaced by a newer one)" });
  res.json(read);
});

for (const action of ["start", "stop", "attach"]) {
  app.post(`/api/sparks/:id/llm-launchers/:lid/${action}`, (req, res) => {
    const spark = launcherContext(req, res);
    if (!spark) return;
    const launcher = launcherStore.get(spark.id, req.params.lid);
    if (!launcher) return res.status(404).json({ error: "Model not found" });
    const limiter = action === "attach" ? allowLaunchProbe : allowLaunch;
    if (!limiter(principalKey(req))) {
      return rejectLimited(res, "Too many start/stop requests; try again shortly");
    }
    const result = launcherManager.startJob(spark, launcher, action);
    if (!result.ok) {
      return res.status(409).json({
        error: `Another job is running on this Spark (${result.active.action} ${result.active.launcherName}). Wait for it or cancel it first.`,
        active: result.active,
      });
    }
    res.status(202).json({ job: result.job });
  });
}

// Cancel a ComfyUI job (running interrupt and/or pending dequeue).
app.post("/api/sparks/:id/comfy/cancel", async (req, res) => {
  if (!allowDestructive(principalKey(req)) || !allowGlobalDestructive(clientKey(req))) {
    return rejectLimited(res, "Too many cancellation requests; try again shortly");
  }
  try {
    const spark = registry.getSpark(req.params.id);
    if (!spark) return res.status(404).json({ error: "Spark not found" });
    if (!spark.comfyMonitoring) {
      return res.status(400).json({ error: "ComfyUI monitoring is disabled for this Spark" });
    }
    const promptId = req.body?.promptId ?? req.body?.prompt_id;
    if (!promptId || typeof promptId !== "string") {
      return res.status(400).json({ error: "promptId is required" });
    }
    const result = await comfyCancelJob(spark, promptId, resolveComfyPort(spark));
    // Nudge a comfy re-poll so UI updates quickly
    const mon = monitors.get(req.params.id);
    if (mon) void mon._pollDomain?.("comfy");
    res.json({ success: result.ok, ...result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Manual metric refresh ──────────────────────────────
app.post("/api/sparks/:id/refresh/:domain", async (req, res) => {
  try {
    const monitor = monitors.get(req.params.id);
    if (!monitor) return res.status(404).json({ error: "Spark not found" });
    const { domain } = req.params;
    if (domain !== "storage" && domain !== "llm") {
      return res.status(400).json({ error: "Only 'storage' and 'llm' domains are supported" });
    }
    await monitor.refreshDomain(domain);
    forceBroadcast();
    res.json({ success: true, domain });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Hermes Agent ───────────────────────────────────
// Batch route first (like shutdown-all/wake-all): a plain Sparks-suffixed
// path (3 segments) that cannot be captured by /api/sparks/:id/hermes/* (4).
/** One-click `hermes update` on every Spark with hermes monitoring enabled. */
app.post("/api/sparks/hermes/update-all", async (_req, res) => {
  const results = [];
  for (const spark of registry.sparks) {
    const monitor = monitors.get(spark.id);
    const entry = { id: spark.id, name: spark.name, ok: false, started: false, skipped: false };
    if (!spark.hermesMonitoring || !monitor) {
      entry.skipped = true;
      entry.reason = spark.hermesMonitoring
        ? "monitor not running"
        : "Hermes Agent monitoring is disabled (enable it in Edit Spark)";
      results.push(entry);
      continue;
    }
    const result = monitor.runHermesUpdate();
    entry.started = Boolean(result.started);
    entry.ok = Boolean(result.started);
    if (!result.started) {
      entry.skipped = true;
      entry.reason = result.reason || "update already running";
    }
    results.push(entry);
  }
  res.json({ success: true, results });
});

/** Re-check for a hermes update now (bypasses the poll cadence). */
app.post("/api/sparks/:id/hermes/check", async (req, res) => {
  try {
    const spark = registry.getSpark(req.params.id);
    if (!spark) return res.status(404).json({ error: "Spark not found" });
    if (!spark.hermesMonitoring) {
      return res.status(400).json({
        error: "Hermes Agent monitoring is disabled for this Spark (enable it in Edit Spark)",
      });
    }
    const monitor = monitors.get(req.params.id);
    if (!monitor) return res.status(404).json({ error: "Spark not found" });
    const result = await monitor.hermesProbe.check();
    monitor.applyHermesCheck(result);
    res.json({ success: true, hermes: monitor.snapshot().hermes });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/** One-click `hermes update` via SSH. Returns 202; progress via snapshot. */
app.post("/api/sparks/:id/hermes/update", async (req, res) => {
  try {
    const spark = registry.getSpark(req.params.id);
    if (!spark) return res.status(404).json({ error: "Spark not found" });
    if (!spark.hermesMonitoring) {
      return res.status(400).json({
        error: "Hermes Agent monitoring is disabled for this Spark (enable it in Edit Spark)",
      });
    }
    const monitor = monitors.get(req.params.id);
    if (!monitor) return res.status(404).json({ error: "Spark not found" });
    const result = await monitor.runHermesUpdate();
    res.status(result.started ? 202 : 200).json({
      success: result.started,
      reason: result.reason,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Per-Spark Hermes update preview: the latest release (cached globally), the
// installed version, the actual pending commits on this Spark (HEAD..origin/main)
// and a resolved `view` so the dialog shows the commit list for minor /
// no-bump updates and the full release changelog only when a real version bump
// is pending.
app.get("/api/sparks/:id/hermes/updates", async (req, res) => {
  try {
    const spark = registry.getSpark(req.params.id);
    if (!spark) return res.status(404).json({ error: "Spark not found" });
    if (!spark.hermesMonitoring) {
      return res.status(400).json({
        error: "Hermes Agent monitoring is disabled for this Spark (enable it in Edit Spark)",
      });
    }
    const monitor = monitors.get(req.params.id);
    if (!monitor) return res.status(404).json({ error: "Spark not found" });

    const installedVersion = monitor.snapshot().hermes?.version || null;
    const pending = await monitor.hermesProbe.pendingCommits();

    let release = null;
    let releaseError = null;
    try {
      release = await getLatestRelease();
    } catch (err) {
      releaseError = err instanceof Error ? err.message : String(err);
    }

    // Resolve which content the dialog should lead with. A version bump exists
    // only when the latest tagged release is newer than what is installed;
    // otherwise the pending update is commits on main and those are the honest
    // changelog. Without both versions, fall back to the release when available.
    const hasPending = Boolean(pending && pending.commits && pending.commits.length > 0);
    const releaseNewer =
      release?.semver && installedVersion && compareSemver(release.semver, installedVersion) > 0;
    const view = releaseNewer ? "release" : hasPending ? "commits" : "release";

    res.json({
      success: true,
      view,
      release,
      releaseError,
      installedVersion,
      pending,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Save / update SSH password only (works while host is offline)
app.put("/api/sparks/:id/password", (req, res) => {
  try {
    const password = req.body?.password ?? req.body?.ssh?.password;
    if (password == null || password === "") {
      return res.status(400).json({ error: "password is required" });
    }
    const spark = registry.setPassword(req.params.id, password);
    // Refresh monitor with password in memory (no need if already running — updateConfig)
    const mon = monitors.get(req.params.id);
    if (mon) mon.updateConfig(registry.getSpark(req.params.id));
    res.json({ success: true, spark, hasPassword: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Update disabled storage devices for a Spark (hot — no monitor restart)
app.put("/api/sparks/:id/disabled-devices", (req, res) => {
  try {
    const spark = registry.getSpark(req.params.id);
    if (!spark) return res.status(404).json({ error: "Spark not found" });

    const { disabledDevices } = req.body;
    if (!Array.isArray(disabledDevices)) {
      return res.status(400).json({ error: "disabledDevices must be an array" });
    }

    const updated = registry.updateSpark(req.params.id, { disabledDevices });
    const monitor = monitors.get(req.params.id);
    if (monitor) {
      monitor.updateConfig(updated);
    } else {
      startMonitor(updated);
    }
    res.json({ success: true, disabledDevices });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Update disabled network interfaces for a Spark (hot — no monitor restart)
app.put("/api/sparks/:id/disabled-interfaces", (req, res) => {
  try {
    const spark = registry.getSpark(req.params.id);
    if (!spark) return res.status(404).json({ error: "Spark not found" });

    const { disabledInterfaces } = req.body;
    if (!Array.isArray(disabledInterfaces)) {
      return res.status(400).json({ error: "disabledInterfaces must be an array" });
    }

    const cleaned = disabledInterfaces.filter((n) => typeof n === "string" && n.length > 0);
    const updated = registry.updateSpark(req.params.id, { disabledInterfaces: cleaned });
    const monitor = monitors.get(req.params.id);
    if (monitor) {
      monitor.updateConfig(updated);
    } else {
      startMonitor(updated);
    }
    res.json({ success: true, disabledInterfaces: cleaned });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Update LLM probe ports for a Spark (hot — no monitor restart)
app.put("/api/sparks/:id/llm-ports", (req, res) => {
  try {
    const spark = registry.getSpark(req.params.id);
    if (!spark) return res.status(404).json({ error: "Spark not found" });

    const raw = req.body?.llmPorts;
    if (!Array.isArray(raw)) {
      return res.status(400).json({ error: "llmPorts must be an array" });
    }
    const ports = raw
      .map((v) => (typeof v === "string" ? parseInt(v, 10) : Number(v)))
      .filter((n) => Number.isInteger(n) && n >= 1 && n <= 65535);
    // Deduplicate
    const unique = [...new Set(ports)];
    if (unique.length === 0) {
      return res.status(400).json({ error: "llmPorts must contain at least one valid port 1–65535" });
    }

    const prevPorts = Array.isArray(spark.llmPorts) ? [...spark.llmPorts] : [];
    const updated = registry.updateSpark(req.params.id, { llmPorts: unique });
    registry.syncLlmApiKeysToPorts(req.params.id, prevPorts, unique);
    const withSecrets = registry.getSpark(req.params.id);
    const monitor = monitors.get(req.params.id);
    if (monitor) {
      monitor.updateConfig(withSecrets);
    } else {
      startMonitor(withSecrets);
    }
    res.json({
      success: true,
      llmPorts: updated.llmPorts,
      llmApiKeyPorts: registry.llmApiKeyPorts(req.params.id),
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Backward-compat: update single LLM port (delegates to llm-ports)
app.put("/api/sparks/:id/llm-port", (req, res) => {
  try {
    const spark = registry.getSpark(req.params.id);
    if (!spark) return res.status(404).json({ error: "Spark not found" });

    const raw = req.body?.llmPort;
    const n = typeof raw === "string" ? parseInt(raw, 10) : Number(raw);
    if (!Number.isInteger(n) || n < 1 || n > 65535) {
      return res.status(400).json({ error: "llmPort must be an integer 1–65535" });
    }

    const prevPorts = Array.isArray(spark.llmPorts) ? [...spark.llmPorts] : [];
    // Replace the ports list with just this single port
    const updated = registry.updateSpark(req.params.id, { llmPorts: [n] });
    registry.syncLlmApiKeysToPorts(req.params.id, prevPorts, [n]);
    const withSecrets = registry.getSpark(req.params.id);
    const monitor = monitors.get(req.params.id);
    if (monitor) {
      monitor.updateConfig(withSecrets);
    } else {
      startMonitor(withSecrets);
    }
    res.json({
      success: true,
      llmPort: n,
      llmPorts: updated.llmPorts,
      llmApiKeyPorts: registry.llmApiKeyPorts(req.params.id),
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Add a single LLM port to a Spark (hot — no monitor restart)
app.post("/api/sparks/:id/llm-ports", (req, res) => {
  try {
    const spark = registry.getSpark(req.params.id);
    if (!spark) return res.status(404).json({ error: "Spark not found" });

    const raw = req.body?.port;
    const n = typeof raw === "string" ? parseInt(raw, 10) : Number(raw);
    if (!Number.isInteger(n) || n < 1 || n > 65535) {
      return res.status(400).json({ error: "port must be an integer 1–65535" });
    }

    const currentPorts = spark.llmPorts || [];
    if (currentPorts.includes(n)) {
      return res.json({ success: true, llmPorts: currentPorts });
    }

    const updated = registry.updateSpark(req.params.id, { llmPorts: [...currentPorts, n] });
    const monitor = monitors.get(req.params.id);
    if (monitor) {
      monitor.updateConfig(updated);
    } else {
      startMonitor(updated);
    }
    res.json({ success: true, llmPorts: updated.llmPorts });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Remove an LLM port from a Spark (hot — no monitor restart)
app.delete("/api/sparks/:id/llm-ports/:port", (req, res) => {
  try {
    const spark = registry.getSpark(req.params.id);
    if (!spark) return res.status(404).json({ error: "Spark not found" });

    const port = parseInt(req.params.port, 10);
    if (!Number.isInteger(port) || port < 1 || port > 65535) {
      return res.status(400).json({ error: "port must be an integer 1–65535" });
    }

    const currentPorts = spark.llmPorts || [];
    // Primary (first) port cannot be removed — only additional ports
    if (currentPorts[0] === port) {
      return res.status(400).json({ error: "Cannot remove the primary LLM port" });
    }
    const newPorts = currentPorts.filter((p) => p !== port);
    if (newPorts.length === 0) {
      return res.status(400).json({ error: "Cannot remove the last LLM port" });
    }
    if (newPorts.length === currentPorts.length) {
      return res.json({ success: true, llmPorts: currentPorts });
    }

    const updated = registry.updateSpark(req.params.id, { llmPorts: newPorts });
    registry.clearLlmApiKey(req.params.id, port);
    const withSecrets = registry.getSpark(req.params.id);
    const monitor = monitors.get(req.params.id);
    if (monitor) {
      monitor.updateConfig(withSecrets);
    } else {
      startMonitor(withSecrets);
    }
    res.json({
      success: true,
      llmPorts: updated.llmPorts,
      llmApiKeyPorts: registry.llmApiKeyPorts(req.params.id),
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Set / clear optional LLM API key for one port (encrypted secrets store)
app.put("/api/sparks/:id/llm-ports/:port/api-key", (req, res) => {
  try {
    const spark = registry.getSpark(req.params.id);
    if (!spark) return res.status(404).json({ error: "Spark not found" });

    const port = parseInt(req.params.port, 10);
    if (!Number.isInteger(port) || port < 1 || port > 65535) {
      return res.status(400).json({ error: "port must be an integer 1–65535" });
    }

    if (!Object.prototype.hasOwnProperty.call(req.body || {}, "apiKey")) {
      return res.status(400).json({ error: "apiKey is required (use \"\" to clear)" });
    }

    const apiKey = req.body.apiKey == null ? "" : String(req.body.apiKey);
    const publicSpark = registry.setLlmApiKey(req.params.id, port, apiKey);
    const withSecrets = registry.getSpark(req.params.id);
    const monitor = monitors.get(req.params.id);
    if (monitor) {
      monitor.updateConfig(withSecrets);
    } else {
      startMonitor(withSecrets);
    }
    res.json({
      success: true,
      spark: publicSpark,
      hasApiKey: registry.hasLlmApiKey(req.params.id, port),
      llmApiKeyPorts: registry.llmApiKeyPorts(req.params.id),
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

/**
 * Daily decode / prefill tok/s rollups (busy samples, last 14 UTC days by default).
 * Query: port (required for multi-port), days (1–30).
 */
app.get("/api/sparks/:id/llm/daily", (req, res) => {
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  const ports =
    Array.isArray(spark.llmPorts) && spark.llmPorts.length
      ? spark.llmPorts
      : [resolveLlmPort(spark)];
  let port = req.query.port != null ? Number(req.query.port) : ports[0];
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    return res.status(400).json({ error: "Invalid port" });
  }
  let days = req.query.days != null ? Number(req.query.days) : 14;
  if (!Number.isFinite(days)) days = 14;
  res.json(llmDaily.getSeries(spark.id, port, { days }));
});

/**
 * Decode throughput benchmark (streaming, post-first-token tok/s).
 *
 * POST body: { port?, concurrencies: number[], maxTokens?, promptType? }
 * promptType is structured | prose | code | json (default structured).
 * Returns immediately with a bench job; poll GET for progress/results.
 */
app.post("/api/sparks/:id/llm/bench", async (req, res) => {
  if (activeBenchJobCount() >= MAX_ACTIVE_BENCH_JOBS) {
    return res.status(429).json({ error: "Global active benchmark cap reached; wait for a job to finish" });
  }
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  if (spark.workerNode) {
    return res.status(400).json({ error: "Worker nodes do not expose a local LLM API" });
  }
  if (spark.llmMonitoring === false) {
    return res.status(400).json({ error: "LLM monitoring is disabled for this Spark" });
  }
  if (showcaseManager.getActive(spark.id)) {
    return res.status(409).json({ error: "A prompt showcase is already running for this Spark" });
  }
  if (prefillBenchManager.getActive(spark.id)) {
    return res.status(409).json({ error: "A prefill benchmark is already running for this Spark" });
  }
  if (qualityBenchManager.getActive(spark.id)) {
    return res.status(409).json({ error: "A quality benchmark is already running for this Spark" });
  }

  const monitor = monitors.get(req.params.id);
  const ports = Array.isArray(spark.llmPorts) && spark.llmPorts.length
    ? spark.llmPorts
    : [resolveLlmPort(spark)];

  let target;
  try {
    target = await benchHttpTarget(spark, ports, req.body || {});
  } catch (err) {
    return res.status(err.status || 400).json({ error: err.message });
  }
  const port = target.port;
  try {
    validateDecodeBudget(normalizeConcurrencies(req.body?.concurrencies), req.body?.maxTokens ?? 400);
  } catch (err) {
    return res.status(err.status || 429).json({ error: err.message });
  }

  // Resolve model id for this port from live snapshot when possible
  let modelId = req.body?.modelId || null;
  if (!modelId && !target.custom && monitor) {
    const snap = monitor.snapshot();
    const llmList = Array.isArray(snap?.metrics?.llm) ? snap.metrics.llm : [];
    const portIndex = ports.indexOf(port);
    const llm =
      (portIndex >= 0 ? llmList[portIndex] : null) ||
      llmList.find((m) => m?.available) ||
      llmList[0];
    modelId = llm?.modelId || null;
  }

  try {
    if (!consumeBenchStartQuota(req, res)) return;
    const benchDebug = Boolean(getSettings().benchDebugTraces);
    const job = decodeBenchManager.start({
      sparkId: spark.id,
      lanIp: llmProbeHost(spark),
      port,
      modelId,
      concurrencies: req.body?.concurrencies,
      maxTokens: req.body?.maxTokens,
      promptType: req.body?.promptType,
      debug: benchDebug,
      apiKey: target.apiKey,
      host: target.host,
      tls: target.tls,
      resolveTarget: target.resolveTarget,
      sampleHardware:
        benchDebug && monitor && !target.custom
          ? async () => {
              const fromGpu = (gpu, um) =>
                gpu
                  ? {
                      gpuUsage: gpu.usage ?? null,
                      temperature: gpu.temperature ?? null,
                      powerDraw: gpu.power?.draw ?? null,
                      powerLimit: gpu.power?.limit ?? null,
                      vramUsed: gpu.vram?.used ?? null,
                      vramTotal: gpu.vram?.total ?? null,
                      vramAvailable: gpu.vram?.available ?? null,
                      memAvailable: um?.available ?? null,
                    }
                  : null;

              // Local: fresh collect so the timeline isn't stuck on the 2s poll cache.
              // Remote: use snapshot only — SSH collectGpu every 1s is too heavy mid-bench.
              if (spark.isLocal) {
                try {
                  const [gpu, um] = await Promise.all([
                    monitor.collector.collectGpu(),
                    monitor.collector.collectUnifiedMemory(),
                  ]);
                  return fromGpu(gpu, um);
                } catch {
                  /* fall through */
                }
              }
              const snap = monitor.snapshot();
              return fromGpu(snap?.metrics?.gpu, snap?.metrics?.unifiedMemory);
            }
          : null,
    });
    res.status(202).json(job);
  } catch (err) {
    const status = err.status || 500;
    res.status(status).json({ error: err.message });
  }
});

app.get("/api/sparks/:id/llm/bench", (req, res) => {
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  const active = decodeBenchManager.getActive(spark.id);
  const history = decodeBenchManager.getHistory(spark.id);
  const portRaw = req.query.port;
  const port =
    portRaw != null && portRaw !== ""
      ? parseInt(String(portRaw), 10)
      : null;
  const last = decodeBenchManager.getLast(
    spark.id,
    Number.isInteger(port) ? port : null
  );
  res.json({
    active,
    last,
    history,
    defaults: DECODE_BENCH_DEFAULTS,
  });
});

/** Clear finished bench history for a Spark (optional ?port=). Does not cancel a running job. */
app.delete("/api/sparks/:id/llm/bench", (req, res) => {
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  if (decodeBenchManager.getActive(spark.id)) {
    return res.status(409).json({ error: "Cannot clear history while a benchmark is running" });
  }
  const portRaw = req.query.port ?? req.body?.port;
  const port =
    portRaw != null && portRaw !== ""
      ? parseInt(String(portRaw), 10)
      : null;
  decodeBenchManager.clearHistory(
    spark.id,
    Number.isInteger(port) ? port : null
  );
  res.json({ success: true });
});

app.get("/api/sparks/:id/llm/bench/:benchId", (req, res) => {
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  const job = decodeBenchManager.getJob(req.params.benchId);
  if (!job || job.sparkId !== spark.id) {
    return res.status(404).json({ error: "Benchmark not found" });
  }
  res.json(job); // already public shape from manager
});

app.delete("/api/sparks/:id/llm/bench/:benchId", (req, res) => {
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  const job = decodeBenchManager.cancel(spark.id, req.params.benchId);
  if (!job) return res.status(404).json({ error: "Benchmark not found" });
  res.json(job);
});

/**
 * Prefill throughput + TTFT at selected context sizes (up to 300k).
 *
 * POST body: { port?, contextSizes: number[] }
 * Returns 202 job; poll GET for progress/results.
 */
app.post("/api/sparks/:id/llm/prefill-bench", async (req, res) => {
  if (activeBenchJobCount() >= MAX_ACTIVE_BENCH_JOBS) {
    return res.status(429).json({ error: "Global active benchmark cap reached; wait for a job to finish" });
  }
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  if (spark.workerNode) {
    return res.status(400).json({ error: "Worker nodes do not expose a local LLM API" });
  }
  if (spark.llmMonitoring === false) {
    return res.status(400).json({ error: "LLM monitoring is disabled for this Spark" });
  }
  if (showcaseManager.getActive(spark.id)) {
    return res.status(409).json({ error: "A prompt showcase is already running for this Spark" });
  }
  if (decodeBenchManager.getActive(spark.id)) {
    return res.status(409).json({ error: "A decode benchmark is already running for this Spark" });
  }
  if (qualityBenchManager.getActive(spark.id)) {
    return res.status(409).json({ error: "A quality benchmark is already running for this Spark" });
  }

  const monitor = monitors.get(req.params.id);
  const ports = Array.isArray(spark.llmPorts) && spark.llmPorts.length
    ? spark.llmPorts
    : [resolveLlmPort(spark)];

  let target;
  try {
    target = await benchHttpTarget(spark, ports, req.body || {});
  } catch (err) {
    return res.status(err.status || 400).json({ error: err.message });
  }
  const port = target.port;
  try {
    validatePrefillBudget(normalizeContextSizes(req.body?.contextSizes));
  } catch (err) {
    return res.status(err.status || 429).json({ error: err.message });
  }

  let contextLength = null;
  let modelId = req.body?.modelId || null;
  if (!modelId && !target.custom && monitor) {
    const snap = monitor.snapshot();
    const llmList = Array.isArray(snap?.metrics?.llm) ? snap.metrics.llm : [];
    const portIndex = ports.indexOf(port);
    const llm =
      (portIndex >= 0 ? llmList[portIndex] : null) ||
      llmList.find((m) => m?.available) ||
      llmList[0];
    modelId = llm?.modelId || null;
    contextLength = Number(llm?.contextLength) > 0 ? Number(llm.contextLength) : null;
  }

  try {
    if (!consumeBenchStartQuota(req, res)) return;
    const job = prefillBenchManager.start({
      contextLength,
      sparkId: spark.id,
      lanIp: llmProbeHost(spark),
      port,
      modelId,
      contextSizes: req.body?.contextSizes,
      apiKey: target.apiKey,
      host: target.host,
      tls: target.tls,
      resolveTarget: target.resolveTarget,
    });
    res.status(202).json(job);
  } catch (err) {
    const status = err.status || 500;
    res.status(status).json({ error: err.message });
  }
});

app.get("/api/sparks/:id/llm/prefill-bench", (req, res) => {
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  const active = prefillBenchManager.getActive(spark.id);
  const history = prefillBenchManager.getHistory(spark.id);
  const portRaw = req.query.port;
  const port =
    portRaw != null && portRaw !== ""
      ? parseInt(String(portRaw), 10)
      : null;
  const last = prefillBenchManager.getLast(
    spark.id,
    Number.isInteger(port) ? port : null
  );
  res.json({
    active,
    last,
    history,
    defaults: PREFILL_BENCH_DEFAULTS,
  });
});

app.delete("/api/sparks/:id/llm/prefill-bench", (req, res) => {
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  if (prefillBenchManager.getActive(spark.id)) {
    return res.status(409).json({ error: "Cannot clear history while a benchmark is running" });
  }
  const portRaw = req.query.port ?? req.body?.port;
  const port =
    portRaw != null && portRaw !== ""
      ? parseInt(String(portRaw), 10)
      : null;
  prefillBenchManager.clearHistory(
    spark.id,
    Number.isInteger(port) ? port : null
  );
  res.json({ success: true });
});

app.get("/api/sparks/:id/llm/prefill-bench/:benchId", (req, res) => {
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  const job = prefillBenchManager.getJob(req.params.benchId);
  if (!job || job.sparkId !== spark.id) {
    return res.status(404).json({ error: "Benchmark not found" });
  }
  res.json(job);
});

app.delete("/api/sparks/:id/llm/prefill-bench/:benchId", (req, res) => {
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  const job = prefillBenchManager.cancel(spark.id, req.params.benchId);
  if (!job) return res.status(404).json({ error: "Benchmark not found" });
  res.json(job);
});

/**
 * Quality bench — fixed deterministic suite (qa, reason, arith, track, gsm8k, mmlu, follow, long).
 *
 * POST body: { port?, categories?, longSizes?, longItems?, concurrency?, label?, modelId?, host?, tls? }
 * Returns 202 job; poll GET :benchId. GET collection returns active, last (full)
 * and history summaries (no per-item rows; fetch a run by id to compare).
 */
app.post("/api/sparks/:id/llm/quality-bench", async (req, res) => {
  if (activeBenchJobCount() >= MAX_ACTIVE_BENCH_JOBS) {
    return res.status(429).json({ error: "Global active benchmark cap reached; wait for a job to finish" });
  }
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  if (spark.workerNode) {
    return res.status(400).json({ error: "Worker nodes do not expose a local LLM API" });
  }
  if (spark.llmMonitoring === false) {
    return res.status(400).json({ error: "LLM monitoring is disabled for this Spark" });
  }
  if (showcaseManager.getActive(spark.id)) {
    return res.status(409).json({ error: "A prompt showcase is already running for this Spark" });
  }
  if (decodeBenchManager.getActive(spark.id)) {
    return res.status(409).json({ error: "A decode benchmark is already running for this Spark" });
  }
  if (prefillBenchManager.getActive(spark.id)) {
    return res.status(409).json({ error: "A prefill benchmark is already running for this Spark" });
  }

  const monitor = monitors.get(req.params.id);
  const ports = Array.isArray(spark.llmPorts) && spark.llmPorts.length
    ? spark.llmPorts
    : [resolveLlmPort(spark)];

  let target;
  try {
    target = await benchHttpTarget(spark, ports, req.body || {});
  } catch (err) {
    return res.status(err.status || 400).json({ error: err.message });
  }
  const port = target.port;
  const options = normalizeQualityOptions(req.body || {});
  if (!options.categories.length) {
    return res.status(400).json({ error: "Select at least one category" });
  }

  // Model id + context length from the live probe; the job falls back to /v1/models.
  let modelId = req.body?.modelId || null;
  let contextLength = null;
  if (!target.custom && monitor) {
    const snap = monitor.snapshot();
    const llmList = Array.isArray(snap?.metrics?.llm) ? snap.metrics.llm : [];
    const portIndex = ports.indexOf(port);
    const llm =
      (portIndex >= 0 ? llmList[portIndex] : null) ||
      llmList.find((m) => m?.available) ||
      llmList[0];
    if (!modelId) modelId = llm?.modelId || null;
    contextLength = llm?.contextLength ?? null;
  }

  try {
    if (!consumeBenchStartQuota(req, res)) return;
    const job = qualityBenchManager.start({
      sparkId: spark.id,
      lanIp: llmProbeHost(spark),
      port,
      modelId,
      contextLength,
      ...options,
      apiKey: target.apiKey,
      host: target.host,
      tls: target.tls,
      resolveTarget: target.resolveTarget,
    });
    res.status(202).json(job);
  } catch (err) {
    const status = err.status || 500;
    res.status(status).json({ error: err.message });
  }
});

app.get("/api/sparks/:id/llm/quality-bench", (req, res) => {
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  const portRaw = req.query.port;
  const port =
    portRaw != null && portRaw !== ""
      ? parseInt(String(portRaw), 10)
      : null;
  const p = Number.isInteger(port) ? port : null;
  res.json({
    active: qualityBenchManager.getActive(spark.id),
    last: qualityBenchManager.getLast(spark.id, p),
    history: qualityBenchManager.getHistorySummaries(spark.id, p),
    defaults: QUALITY_BENCH_DEFAULTS,
  });
});

app.delete("/api/sparks/:id/llm/quality-bench", (req, res) => {
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  if (qualityBenchManager.getActive(spark.id)) {
    return res.status(409).json({ error: "Cannot clear history while a benchmark is running" });
  }
  const portRaw = req.query.port ?? req.body?.port;
  const port =
    portRaw != null && portRaw !== ""
      ? parseInt(String(portRaw), 10)
      : null;
  qualityBenchManager.clearHistory(
    spark.id,
    Number.isInteger(port) ? port : null
  );
  res.json({ success: true });
});

app.get("/api/sparks/:id/llm/quality-bench/:benchId", (req, res) => {
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  const job = qualityBenchManager.getJob(req.params.benchId);
  if (!job || job.sparkId !== spark.id) {
    return res.status(404).json({ error: "Benchmark not found" });
  }
  res.json(job);
});

app.delete("/api/sparks/:id/llm/quality-bench/:benchId", (req, res) => {
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  const job = qualityBenchManager.cancel(spark.id, req.params.benchId);
  if (!job) return res.status(404).json({ error: "Benchmark not found" });
  res.json(job);
});

/**
 * LLM Prompt Showcase — concurrent streaming demos.
 *
 * POST body: { port, modelId?, maxTokens?, temperature?, thinking?, promptType?, prompts: string[] }
 * Returns 202 { sessionId }; poll GET for deltas; DELETE :sessionId to cancel.
 * Finished runs are archived; GET collection lists history; DELETE collection clears it.
 */
app.post("/api/sparks/:id/llm/showcase", (req, res) => {
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  if (spark.workerNode) {
    return res.status(403).json({ error: "Worker nodes do not expose a local LLM API" });
  }
  if (spark.llmMonitoring === false) {
    return res.status(403).json({ error: "LLM monitoring is disabled for this Spark" });
  }

  const monitor = monitors.get(req.params.id);
  const ports = Array.isArray(spark.llmPorts) && spark.llmPorts.length
    ? spark.llmPorts
    : [resolveLlmPort(spark)];

  if (req.body?.port == null) {
    return res.status(400).json({ error: "port is required" });
  }
  const port = Number(req.body.port);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    return res.status(400).json({ error: "Invalid port" });
  }
  if (!ports.includes(port)) {
    return res.status(400).json({ error: "port is not configured for this Spark" });
  }

  let modelId = req.body?.modelId || null;
  if (!modelId && monitor) {
    const snap = monitor.snapshot();
    const llmList = Array.isArray(snap?.metrics?.llm) ? snap.metrics.llm : [];
    const portIndex = ports.indexOf(port);
    const llm =
      (portIndex >= 0 ? llmList[portIndex] : null) ||
      llmList.find((m) => m?.available) ||
      llmList[0];
    modelId = llm?.modelId || null;
  }

  try {
    const result = showcaseManager.start({
      sparkId: spark.id,
      lanIp: llmProbeHost(spark),
      port,
      modelId,
      maxTokens: req.body?.maxTokens,
      temperature: req.body?.temperature,
      thinking: req.body?.thinking,
      promptType: req.body?.promptType,
      prompts: req.body?.prompts,
      apiKey: resolveLlmApiKey(spark, port),
    });
    res.status(202).json(result);
  } catch (err) {
    const status = err.status || 500;
    res.status(status).json({ error: err.message });
  }
});

/** Active session + finished history summaries (no stream bodies). */
app.get("/api/sparks/:id/llm/showcase", (req, res) => {
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  if (spark.workerNode) {
    return res.status(403).json({ error: "Worker nodes do not expose a local LLM API" });
  }
  if (spark.llmMonitoring === false) {
    return res.status(403).json({ error: "LLM monitoring is disabled for this Spark" });
  }

  res.json({
    active: showcaseManager.getActive(spark.id),
    history: showcaseManager.getHistory(spark.id),
  });
});

/** Clear finished showcase history for a Spark. Does not cancel a running session. */
app.delete("/api/sparks/:id/llm/showcase", (req, res) => {
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  if (spark.workerNode) {
    return res.status(403).json({ error: "Worker nodes do not expose a local LLM API" });
  }
  if (spark.llmMonitoring === false) {
    return res.status(403).json({ error: "LLM monitoring is disabled for this Spark" });
  }
  if (showcaseManager.getActive(spark.id)) {
    return res.status(409).json({ error: "Cannot clear history while a showcase is running" });
  }
  showcaseManager.clearHistory(spark.id);
  res.json({ success: true });
});

app.get("/api/sparks/:id/llm/showcase/:sessionId", (req, res) => {
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  if (spark.workerNode) {
    return res.status(403).json({ error: "Worker nodes do not expose a local LLM API" });
  }
  if (spark.llmMonitoring === false) {
    return res.status(403).json({ error: "LLM monitoring is disabled for this Spark" });
  }

  const sinceRaw = req.query.since;
  const since =
    sinceRaw != null && sinceRaw !== ""
      ? parseInt(String(sinceRaw), 10)
      : null;
  const session = showcaseManager.getSession(
    spark.id,
    req.params.sessionId,
    Number.isInteger(since) ? since : null
  );
  if (!session) return res.status(404).json({ error: "Showcase session not found" });
  res.json(session);
});

app.delete("/api/sparks/:id/llm/showcase/:sessionId", (req, res) => {
  const spark = registry.getSpark(req.params.id);
  if (!spark) return res.status(404).json({ error: "Spark not found" });
  if (spark.workerNode) {
    return res.status(403).json({ error: "Worker nodes do not expose a local LLM API" });
  }
  if (spark.llmMonitoring === false) {
    return res.status(403).json({ error: "LLM monitoring is disabled for this Spark" });
  }

  const session = showcaseManager.cancel(spark.id, req.params.sessionId);
  if (!session) return res.status(404).json({ error: "Showcase session not found" });
  res.json(session);
});

// ─── Power management ────────────────────────────────────
// Shutdown uses the host script /usr/local/bin/spark-shutdown (see server/shutdown.js
// for the local host-namespace drop and the remote command string).
// These routes sit behind the same auth middleware as every other mutation: a
// bearer token when SPARKDASH_TOKEN is set, otherwise open on loopback and on an
// open remote bind — so do not expose port 5555 beyond a trusted network.

/** Remote: verify script + passwordless sudo, then background shutdown so SSH
 * returns before the host dies. Failures before backgrounding surface to the UI. */
const SHUTDOWN_REMOTE_CMD = remoteShutdownCommand();

function shutdownErrorStatus(msg) {
  if (/timed out|connection refused|unreachable|no route|ECONNREFUSED|ETIMEDOUT/i.test(msg)) {
    return 503;
  }
  return 500;
}

/**
 * Only treat "host dropped the SSH session mid-shutdown" as success.
 * Connect timeouts / auth / missing script must remain real errors.
 */
function isBenignShutdownSshError(msg) {
  return /ECONNRESET|Connection reset|broken pipe|Connection closed by remote|closed by remote host|Connection to .* closed/i.test(
    String(msg || "")
  );
}

/**
 * Kick off graceful shutdown. Always aims to return quickly so the browser
 * gets a real JSON response instead of "Failed to fetch" when the SSH session
 * drops as the host powers off.
 */
function initiateSparkShutdown(spark) {
  const noteShutdown = () => {
    recordEvent({
      type: "power.shutdown",
      severity: "warn",
      sparkId: spark.id,
      sparkName: spark.name,
      message: `Shutdown requested for ${spark.name || spark.id}`,
    });
    eventLog.flush(); // the local host may power off right after this
  };
  if (spark.isLocal) {
    noteShutdown();
    return spawnLocalShutdown();
  }

  const shutdownCmd = spark.platform === "windows" ? "shutdown.exe /s /t 5 /c sparkDash" : SHUTDOWN_REMOTE_CMD;
  return sshExec(spark, shutdownCmd, { timeoutMs: 8000 })
    .then(() => {
      noteShutdown();
      return "Shutdown initiated";
    })
    .catch((err) => {
      const msg = err.message || String(err);
      if (isBenignShutdownSshError(msg)) {
        noteShutdown();
        return "Shutdown initiated";
      }
      throw err;
    });
}

function noteWake(spark) {
  recordEvent({
    type: "power.wake",
    severity: "info",
    sparkId: spark.id,
    sparkName: spark.name,
    message: `Wake-on-LAN sent to ${spark.name || spark.id}`,
  });
}

/** Batch routes first so they never collide with /:id/* if routing changes. */
app.post("/api/sparks/shutdown-all", async (_req, res) => {
  const results = [];
  // Remotes first, local last — shutting down the dashboard host mid-loop would
  // skip remaining Sparks.
  const ordered = [
    ...registry.sparks.filter((s) => !s.isLocal),
    ...registry.sparks.filter((s) => s.isLocal),
  ];
  for (const spark of ordered) {
    const monitor = monitors.get(spark.id);
    if (!monitor?.online) {
      results.push({ id: spark.id, ok: false, skipped: true, error: "Offline — skipped" });
      continue;
    }
    try {
      // Local dashboard host: acknowledge before power-off kills this process.
      if (spark.isLocal) {
        results.push({ id: spark.id, ok: true, message: "Shutdown initiated" });
        setImmediate(() => {
          void initiateSparkShutdown(spark).catch((err) => {
            console.error(`[shutdown-all] local ${spark.id}:`, err.message);
          });
        });
        continue;
      }
      await initiateSparkShutdown(spark);
      results.push({ id: spark.id, ok: true });
    } catch (err) {
      results.push({ id: spark.id, ok: false, error: err.message || String(err) });
    }
  }
  res.json({ success: true, results });
});

app.post("/api/sparks/wake-all", async (_req, res) => {
  const results = [];
  for (const spark of registry.sparks) {
    if (spark.kind !== "host") {
      results.push({
        id: spark.id,
        ok: false,
        skipped: true,
        error: "DGX Spark does not support Wake-on-LAN",
      });
      continue;
    }
    const cleanMac = effectiveMac(spark);
    if (!cleanMac) {
      results.push({
        id: spark.id,
        ok: false,
        error: "No MAC address (enP7s7 not seen yet; set override in Edit Spark)",
      });
      continue;
    }
    try {
      const broadcast = broadcastForLanIp(spark.lanIp);
      const sent = await sendWol(cleanMac, broadcast);
      noteWake(spark);
      results.push({ id: spark.id, ok: true, mac: sent.mac, broadcast: sent.broadcast });
    } catch (err) {
      results.push({ id: spark.id, ok: false, error: err.message || String(err) });
    }
  }
  res.json({ success: true, results });
});

app.post("/api/sparks/:id/shutdown", async (req, res) => {
  try {
    const spark = registry.getSpark(req.params.id);
    if (!spark) return res.status(404).json({ error: "Spark not found" });

    // Local: send JSON first, then power off — otherwise the process dies mid-response
    // and the UI shows "Failed to fetch".
    if (spark.isLocal) {
      res.json({ success: true, message: "Shutdown initiated" });
      setImmediate(() => {
        void initiateSparkShutdown(spark).catch((err) => {
          console.error(`[shutdown] local ${spark.id}:`, err.message);
        });
      });
      return;
    }

    try {
      const message = await initiateSparkShutdown(spark);
      res.json({ success: true, message, output: message });
    } catch (err) {
      const msg = err.message || String(err);
      res.status(shutdownErrorStatus(msg)).json({
        error: shutdownErrorStatus(msg) === 503 ? `Spark unreachable: ${msg}` : msg,
      });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/sparks/:id/wake", async (req, res) => {
  try {
    const spark = registry.getSpark(req.params.id);
    if (!spark) return res.status(404).json({ error: "Spark not found" });
    if (spark.kind !== "host") {
      return res.status(400).json({
        error: "DGX Spark does not support Wake-on-LAN. The onboard NIC does not wake from a magic packet.",
      });
    }

    // Body mac > user override > auto-detected enP7s7
    const cleanMac = normalizeMac(req.body?.mac) || effectiveMac(spark);
    if (!cleanMac) {
      if (req.body?.mac || spark.macAddress) {
        return res.status(400).json({
          error: `Invalid MAC address: ${req.body?.mac || spark.macAddress}`,
        });
      }
      return res.status(400).json({
        error:
          "No MAC address yet. Wait until the node is online so enP7s7 can be detected, or set a MAC override in Edit Spark.",
      });
    }

    const broadcast = broadcastForLanIp(spark.lanIp);
    try {
      const sent = await sendWol(cleanMac, broadcast);
      noteWake(spark);
      res.json({
        success: true,
        message: `Magic packet sent to ${sent.mac} via ${sent.broadcast}`,
        mac: sent.mac,
        broadcast: sent.broadcast,
      });
    } catch (err) {
      res.status(500).json({ error: `WoL send failed: ${err.message || String(err)}` });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Prometheus exposition (opt-in) ──────────────────────
// Registered after the auth middleware (a token-protected install needs the
// scraper's bearer token) and before the SPA fallback, which would otherwise
// answer /metrics with index.html.
app.get("/metrics", (_req, res) => {
  res.set("Cache-Control", "no-store");
  if (!getSettings().prometheusExport) {
    return res
      .status(404)
      .type("text")
      .send("Prometheus export is off. Enable it in Settings → Prometheus metrics.\n");
  }
  const entries = metricsEntries(registry.sparkIds.map((id) => monitors.get(id)));
  // res.end, not res.send: send() reorders the media type parameters; keep the
  // header exactly as the exposition format spells it.
  res.setHeader("Content-Type", PROMETHEUS_CONTENT_TYPE);
  res.end(renderPrometheusMetrics(entries));
});

// ─── Static files (built frontend) ───────────────────────
const staticByDir = new Map();
app.use((req, res, next) => {
  const dir = resolveFrontendDir(ROOT);
  if (!dir) return next();
  if (!staticByDir.has(dir)) staticByDir.set(dir, express.static(dir));
  return staticByDir.get(dir)(req, res, next);
});

// ─── SPA fallback (Express v5 wildcard) ───────────────────
app.get("*splat", (_req, res) => {
  const dir = resolveFrontendDir(ROOT);
  if (!dir) {
    return res.status(503).type("text").send(FRONTEND_MISSING_MESSAGE);
  }
  res.sendFile(path.join(dir, "index.html"));
});

// ─── Process-level safety net ─────────────────────────────
// Transient socket / probe errors (a reset connection, a rejected fire-and-forget
// promise) must be logged, not take the whole dashboard down. Programmer errors
// still surface in the log with a stack.
process.on("unhandledRejection", (reason) => {
  console.error("[process] unhandled rejection:", reason instanceof Error ? reason.stack || reason.message : reason);
});
process.on("uncaughtException", (err) => {
  console.error("[process] uncaught exception:", err?.stack || err);
});

// ─── WebSocket ──────────────────────────────────────────
const wss = new WebSocketServer({
  server,
  path: "/ws",
  // The dashboard only ever receives; clients send nothing meaningful.
  maxPayload: 64 * 1024,
  verifyClient: ({ req }, done) => done(authorizeUpgrade(req)),
});
wss.on("error", (err) => {
  console.error("[ws] server error:", err?.message);
});
wss.on("connection", (ws) => {
  console.log("[ws] client connected");
  // A malformed frame or reset socket emits "error" on the socket; without a
  // listener that is an uncaught exception that kills the process.
  ws.on("error", (err) => {
    console.warn("[ws] client error:", err?.message);
  });
  // This snapshot belongs only to the new client. Broadcasting it would add a
  // duplicate history sample to every existing dashboard whenever a tab opens.
  try {
    ws.send(buildSnapshotPayload());
  } catch {
    // The close handler will clean up a client that disappears during connect.
  }
  ws.on("close", () => {
    console.log("[ws] client disconnected");
  });
});

// ─── Broadcast snapshot (dynamic interval) ────────────────
let broadcastTimer = null;
let _lastBroadcastPayload = null;

/** Build the snapshot payload string. Centralized so broadcast + refresh share it. */
function buildSnapshotPayload() {
  return JSON.stringify({
    type: "snapshot",
    generatedAt: Date.now(),
    sparks: orderedSnapshots(),
    refreshInterval: getSettings().pollIntervalMs,
  });
}

/**
 * Send a payload to every open WS client.
 * - Drops clients whose send queue is backlogged (>1 MB) to avoid unbounded
 *   buffering on slow/flaky connections (e.g. phone over spotty WiFi).
 * - Returns the payload so callers can compare against the previous broadcast.
 */
function broadcastPayload(payload) {
  wss.clients.forEach((client) => {
    if (client.readyState !== 1) return; // OPEN only
    if (client.bufferedAmount > 1_000_000) {
      try {
        client.close(1008, "client too slow");
      } catch {
        /* ignore */
      }
      return;
    }
    try {
      client.send(payload);
    } catch {
      /* per-client send failure — ignore, close handler will clean up */
    }
  });
}

/**
 * Force an immediate broadcast, ignoring the diff cache.
 * Used after a user action (manual refresh / hermes check / update) so the
 * UI reflects the result right away instead of on the next poll tick.
 */
function forceBroadcast() {
  const payload = buildSnapshotPayload();
  _lastBroadcastPayload = payload;
  broadcastPayload(payload);
}

function startBroadcast() {
  const interval = getSettings().pollIntervalMs;
  broadcastTimer = setInterval(() => {
    const payload = buildSnapshotPayload();
    // Skip the broadcast entirely when nothing changed since the last tick.
    // A 1s poll that produces identical snapshots becomes free for idle tabs.
    if (_lastBroadcastPayload !== null && payload === _lastBroadcastPayload) return;
    _lastBroadcastPayload = payload;
    broadcastPayload(payload);
  }, interval);
}

function restartBroadcast() {
  if (broadcastTimer) {
    clearInterval(broadcastTimer);
    broadcastTimer = null;
  }
  _lastBroadcastPayload = null; // force a fresh broadcast on the new cadence
  startBroadcast();
}

// ─── Start ───────────────────────────────────────────────
loadSettings();
const startupPreflight = inspectStartupPreflight(BIND_HOST);
logStartupPreflight(startupPreflight, BIND_HOST, PORT);

if (!startupPreflight.fatal) {
  startBroadcast();
  if (isLoopbackBind(BIND_HOST)) {
    // Learn this machine's MagicDNS name (via the host namespace in Docker) so Tailscale Serve
    // needs no SPARKDASH_ALLOWED_HOSTS entry; re-checked now and then in case tailscaled starts later.
    const learnTailscaleName = () =>
      new TailscaleProbe({ isLocal: true }).probe().then(({ dnsName }) => dnsName && setTailscaleName(dnsName));
    learnTailscaleName();
    setInterval(learnTailscaleName, 10 * 60 * 1000).unref();
  }
  server.listen(PORT, BIND_HOST, () => {
    console.log(`[sparkDash] server listening on http://${BIND_HOST}:${PORT}`);
    console.log(`[sparkDash] WebSocket endpoint ws://${BIND_HOST}:${PORT}/ws`);
    const { authMode } = inspectHealth(BIND_HOST);
    console.log(`[sparkDash] bind=${BIND_HOST} auth=${authMode}`);
    if (authMode === "open-remote") {
      console.warn("[sparkDash] WARNING: remote bind without SPARKDASH_TOKEN is OPEN — anyone who can reach this port can change settings and power units off. Set SPARKDASH_TOKEN to require a token.");
    }
    startAllMonitors();
    fleetEnergyRuntime.start();
    llmTokenRuntime.start();
  });
} else {
  process.exitCode = 1;
}

// ─── Graceful shutdown ─────────────────────────────────
let _shuttingDown = false;
async function shutdown(signal) {
  if (_shuttingDown) return;
  _shuttingDown = true;
  console.log(`[sparkDash] ${signal} received, shutting down…`);
  try {
    // Finalize in-flight benches before the process dies so clients polling
    // GET /llm/bench/:id do not hit "Benchmark not found" after --watch reload.
    decodeBenchManager.interruptAll(
      "Interrupted — server restarted while the benchmark was running"
    );
    prefillBenchManager.interruptAll(
      "Interrupted — server restarted while the benchmark was running"
    );
    qualityBenchManager.interruptAll(
      "Interrupted — server restarted while the benchmark was running"
    );
  } catch (err) {
    console.error("[sparkDash] failed to finalize benchmarks:", err.message);
  }
  try {
    launcherManager.shutdown();
    toolEvalManager.shutdown();
  } catch (err) {
    console.error("[sparkDash] failed to stop launcher watchers:", err.message);
  }
  try {
    eventLog.flush();
  } catch (err) {
    console.error("[sparkDash] failed to flush event log:", err.message);
  }
  try {
    clearInterval(gpuHistoryTimer);
    gpuHistory.stop();
  } catch (err) {
    console.error("[sparkDash] failed to flush GPU history:", err.message);
  }
  try {
    llmDaily.flush();
  } catch (err) {
    console.error("[sparkDash] failed to flush LLM daily history:", err.message);
  }
  llmTokenRuntime.stop();
  const energyPersistenceSucceeded = fleetEnergyRuntime.stop();
  const streamAgentClosedGracefully = await closeLlmStreamAgent();
  if (!streamAgentClosedGracefully) {
    console.warn("[sparkDash] LLM dispatcher close timed out; destroyed open sockets");
  }
  try {
    if (broadcastTimer) {
      clearInterval(broadcastTimer);
      broadcastTimer = null;
    }
    for (const m of monitors.values()) m.stop();
    monitors.clear();
  } catch (err) {
    console.error("[sparkDash] error during shutdown:", err.message);
  }
  // Tell WS clients the server is going away, then close the server.
  try {
    wss.clients.forEach((c) => {
      try {
        c.close(1001, "server shutting down");
      } catch {
        /* ignore */
      }
    });
  } catch {
    /* ignore */
  }
  wss.close();
  server.close(() => process.exit(energyPersistenceSucceeded ? 0 : 1));
  // Safety net: if server.close hangs (lingering keep-alive), force-exit.
  setTimeout(() => process.exit(1), 3000).unref();
}
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));

export { app, server, wss };
