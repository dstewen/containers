import { test } from "node:test";
import { strict as assert } from "node:assert";
import fs from "fs";
import os from "os";
import path from "path";
import {
  LlmTokenLedger,
  extractTokenObservations,
  normalizeLlmTokenRange,
} from "../LlmTokenLedger.js";
import {
  createLlmTokenRuntime,
  registerLlmTokenTotalsRoute,
} from "../LlmTokenRuntime.js";

function tmpLedger() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "llm-tokens-"));
  return new LlmTokenLedger(path.join(dir, "llm-token-totals.json"));
}

function obs(sparkId, port, modelId, output, prompt, cached) {
  return { sparkId, port, modelId, output, prompt, cached: cached ?? null };
}

test("extractTokenObservations: aligns metrics.llm with llmPorts and skips invalid rows", () => {
  const snapshots = [
    {
      id: "spark-a",
      llmPorts: [8888, 8000],
      metrics: {
        llm: [
          { available: true, modelId: "org/model-a", totalOutputTokens: 100, totalPromptTokens: 500 },
          { available: false, modelId: "org/model-b", totalOutputTokens: 999 },
        ],
      },
    },
    { id: "spark-b", llmPorts: [8888], metrics: { llm: [{ available: true, totalOutputTokens: 7 }] } },
    { id: "spark-c", llmPorts: [8888], metrics: { llm: [{ available: true }] } }, // no counter
    { id: "spark-d", llmPorts: [8888, 8000], metrics: { llm: [{ available: true, totalOutputTokens: 1 }] } }, // length mismatch
  ];
  const rows = extractTokenObservations(snapshots);
  assert.equal(rows.length, 2);
  assert.deepEqual(rows[0], {
    sparkId: "spark-a",
    port: 8888,
    modelId: "org/model-a",
    output: 100,
    prompt: 500,
    cached: null,
  });
  assert.deepEqual(rows[1], {
    sparkId: "spark-b",
    port: 8888,
    modelId: null,
    output: 7,
    prompt: null,
    cached: null,
  });
});

test("LlmTokenLedger: seeds baseline on first observation, credits deltas after", () => {
  const ledger = tmpLedger();
  const t0 = 1_730_000_000_000;
  ledger.record([obs("spark-a", 8888, "org/model", 1000, 5000)], t0);
  // Snapshot: totals empty (baseline only).
  assert.equal(ledger.snapshot().series[0].models.length, 0);

  ledger.record([obs("spark-a", 8888, "org/model", 1100, 6000)], t0 + 10_000);
  const s = ledger.snapshot().series[0];
  assert.equal(s.models.length, 1);
  assert.equal(s.models[0].modelId, "org/model");
  assert.equal(s.models[0].completionTokens, 100);
  assert.equal(s.models[0].promptTokens, 1000);
  assert.equal(s.totals.completionTokens, 100);
});

test("LlmTokenLedger: attributes deltas to the model active at each observation", () => {
  const ledger = tmpLedger();
  const t0 = 1_730_000_000_000;
  ledger.record([obs("spark-a", 8888, "org/a", 100, 10)], t0);
  ledger.record([obs("spark-a", 8888, "org/a", 150, 60)], t0 + 5_000);
  ledger.record([obs("spark-a", 8888, "org/b", 250, 80)], t0 + 10_000);
  // Same tick batch: two models credited together.
  ledger.record(
    [obs("spark-a", 8888, "org/b", 260, 90), obs("spark-a", 8000, "org/c", 10, 5)],
    t0 + 15_000
  );

  const byModel = Object.fromEntries(
    ledger
      .snapshot()
      .series.filter((s) => s.port === 8888)
      .flatMap((s) => s.models.map((m) => [m.modelId, m]))
  );
  assert.equal(byModel["org/a"].completionTokens, 50);
  assert.equal(byModel["org/b"].completionTokens, 110); // 100 + 10
  assert.equal(byModel["org/b"].promptTokens, 30); // 20 + 10
});

test("LlmTokenLedger: fallback keeps last known model when probe omits modelId", () => {
  const ledger = tmpLedger();
  const t0 = 1_730_000_000_000;
  ledger.record([obs("spark-a", 8888, "org/a", 100, 0)], t0);
  ledger.record([obs("spark-a", 8888, null, 140, 10)], t0 + 5_000);
  const s = ledger.snapshot().series[0];
  assert.equal(s.models.length, 1);
  assert.equal(s.models[0].modelId, "org/a");
  assert.equal(s.models[0].completionTokens, 40);
  assert.equal(s.lastModelId, "org/a");
});

test("LlmTokenLedger: a missing model id warns on the second sample, not the first", () => {
  const ledger = tmpLedger();
  const warnings = [];
  const orig = console.warn;
  console.warn = (...args) => warnings.push(args.join(" "));
  try {
    const t0 = 1_730_000_000_000;
    ledger.record([obs("spark-a", 8888, "org/a", 100, 0)], t0);
    ledger.record([obs("spark-a", 8888, null, 140, 10)], t0 + 5_000);
    assert.equal(warnings.length, 0);
    ledger.record([obs("spark-a", 8888, null, 180, 20)], t0 + 10_000);
    assert.equal(warnings.length, 1);
    assert.match(warnings[0], /spark-a:8888/);
    assert.match(warnings[0], /org\/a/);
    ledger.record([obs("spark-a", 8888, "org/b", 200, 30)], t0 + 15_000);
    assert.equal(warnings.length, 1);
    assert.equal(ledger.snapshot().series[0].lastModelId, "org/b");
  } finally {
    console.warn = orig;
  }
});

test("LlmTokenLedger: counter reset (engine restart) re-seeds without crediting", () => {
  const ledger = tmpLedger();
  const t0 = 1_730_000_000_000;
  ledger.record([obs("spark-a", 8888, "org/a", 1000, 5000)], t0);
  ledger.record([obs("spark-a", 8888, "org/a", 1100, 6000)], t0 + 5_000);
  // Engine restarted: counters back to near zero.
  ledger.record([obs("spark-a", 8888, "org/a", 5, 10)], t0 + 10_000);
  // New traffic after restart.
  ledger.record([obs("spark-a", 8888, "org/a", 25, 30)], t0 + 15_000);

  const s = ledger.snapshot().series[0];
  assert.equal(s.models.length, 1);
  // Only post-restart delta (20) credited; pre-restart total (100) survives.
  assert.equal(s.models[0].completionTokens, 120);
  assert.equal(s.models[0].promptTokens, 1020);
});

test("LlmTokenLedger: daily buckets credit deltas and serve ranged snapshots", () => {
  const ledger = tmpLedger();
  // Two UTC days apart (2026-10-27 and 2026-10-28).
  const d1 = Date.UTC(2026, 9, 27, 23, 0, 0);
  const d2 = Date.UTC(2026, 9, 28, 10, 0, 0);
  ledger.record([obs("spark-a", 8888, "org/a", 100, 10)], d1);
  ledger.record([obs("spark-a", 8888, "org/a", 200, 20)], d1 + 60_000);
  ledger.record([obs("spark-a", 8888, "org/a", 300, 40)], d2);

  // Lifetime includes everything.
  const all = ledger.snapshot("all", d2).series[0];
  assert.equal(all.models[0].completionTokens, 200);

  // "today" (day of d2) only includes the d2 delta.
  const today = ledger.snapshot("today", d2).series[0];
  assert.equal(today.models.length, 1);
  assert.equal(today.models[0].completionTokens, 100);
  assert.equal(today.models[0].promptTokens, 20);
  assert.equal(today.models[0].lastSeenAt, null);

  // 7d/14d/30d windows include both days.
  const seven = ledger.snapshot("7d", d2).series[0];
  assert.equal(seven.models[0].completionTokens, 200);
  assert.equal(ledger.snapshot("30d", d2).range, "30d");

  // Invalid range falls back to lifetime.
  assert.equal(ledger.snapshot("nonsense", d2).range, "all");
});

test("LlmTokenLedger: cached tokens credit as a subset of prompt", () => {
  const ledger = tmpLedger();
  const t0 = 1_730_000_000_000;
  ledger.record([obs("spark-a", 8888, "org/a", 100, 1000, 600)], t0); // seed
  ledger.record([obs("spark-a", 8888, "org/a", 150, 2000, 1400)], t0 + 10_000);
  const s = ledger.snapshot().series[0];
  assert.equal(s.models[0].promptTokens, 1000);
  assert.equal(s.models[0].cachedTokens, 800); // 1400 - 600
  assert.equal(s.models[0].completionTokens, 50);
  assert.equal(s.totals.cachedTokens, 800);
  assert.ok(s.models[0].cachedTokens <= s.models[0].promptTokens);
});

test("LlmTokenLedger: cached delta clamps to prompt delta (no over-credit)", () => {
  const ledger = tmpLedger();
  const t0 = 1_730_000_000_000;
  ledger.record([obs("spark-a", 8888, "org/a", 100, 1000, 600)], t0);
  // Cached jumped far more than prompt — excess must not exceed the prompt bucket.
  ledger.record([obs("spark-a", 8888, "org/a", 150, 1100, 3000)], t0 + 10_000);
  const s = ledger.snapshot().series[0];
  assert.equal(s.models[0].promptTokens, 2400); // 100 + excess absorbed
  assert.equal(s.models[0].cachedTokens, 2400);
  assert.ok(s.models[0].cachedTokens <= s.models[0].promptTokens);
});

test("LlmTokenLedger: backends without the split keep cachedTokens at 0", () => {
  const ledger = tmpLedger();
  const t0 = 1_730_000_000_000;
  ledger.record([obs("spark-a", 8888, "org/a", 100, 1000)], t0); // no cached field
  ledger.record([obs("spark-a", 8888, "org/a", 150, 2000)], t0 + 10_000);
  const s = ledger.snapshot().series[0];
  assert.equal(s.models[0].cachedTokens, 0);
  assert.equal(s.models[0].promptTokens, 1000);
});

test("LlmTokenLedger: daily buckets carry the cached split", () => {
  const ledger = tmpLedger();
  const d1 = Date.UTC(2026, 9, 28, 12, 0, 0);
  ledger.record([obs("spark-a", 8888, "org/a", 100, 1000, 400)], d1);
  ledger.record([obs("spark-a", 8888, "org/a", 150, 2000, 900)], d1 + 60_000);
  const today = ledger.snapshot("today", d1 + 120_000).series[0];
  assert.equal(today.models[0].promptTokens, 1000);
  assert.equal(today.models[0].cachedTokens, 500);
});

test("LlmTokenLedger: persistence round-trips the cached split", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "llm-tokens-"));
  const file = path.join(dir, "llm-token-totals.json");
  const t0 = 1_730_000_000_000;
  const first = new LlmTokenLedger(file);
  first.record([obs("spark-a", 8888, "org/a", 100, 1000, 600)], t0);
  first.record([obs("spark-a", 8888, "org/a", 150, 2000, 1400)], t0 + 60_000);
  first.close();
  const second = new LlmTokenLedger(file);
  second.record([obs("spark-a", 8888, "org/a", 200, 2500, 1700)], t0 + 120_000);
  const s = second.snapshot().series[0];
  assert.equal(s.models[0].promptTokens, 1500);
  assert.equal(s.models[0].cachedTokens, 1100);
});

test("normalizeLlmTokenRange: accepts the documented keys only", () => {
  assert.equal(normalizeLlmTokenRange("today"), "today");
  assert.equal(normalizeLlmTokenRange("7d"), "7d");
  assert.equal(normalizeLlmTokenRange("14d"), "14d");
  assert.equal(normalizeLlmTokenRange("30d"), "30d");
  assert.equal(normalizeLlmTokenRange("all"), "all");
  assert.equal(normalizeLlmTokenRange(undefined), "all");
  assert.equal(normalizeLlmTokenRange("week"), "all");
});

test("LlmTokenLedger: persistence round-trips daily buckets", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "llm-tokens-"));
  const file = path.join(dir, "llm-token-totals.json");
  const t0 = Date.UTC(2026, 9, 28, 12, 0, 0);
  const first = new LlmTokenLedger(file);
  first.record([obs("spark-a", 8888, "org/a", 100, 10)], t0);
  first.record([obs("spark-a", 8888, "org/a", 150, 20)], t0 + 60_000);
  first.close();

  const second = new LlmTokenLedger(file);
  const today = second.snapshot("today", t0 + 120_000).series[0];
  assert.equal(today.models[0].completionTokens, 50);
  assert.equal(today.models[0].promptTokens, 10);
});

test("LlmTokenLedger: persistence round-trips counters", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "llm-tokens-"));
  const file = path.join(dir, "llm-token-totals.json");
  const t0 = 1_730_000_000_000;
  const first = new LlmTokenLedger(file);
  first.record([obs("spark-a", 8888, "org/a", 100, 10)], t0);
  first.record([obs("spark-a", 8888, "org/a", 160, 60)], t0 + 5_000);
  first.close();

  const second = new LlmTokenLedger(file);
  second.record([obs("spark-a", 8888, "org/a", 200, 100)], t0 + 10_000);
  const s = second.snapshot().series[0];
  assert.equal(s.models[0].completionTokens, 100);
  assert.equal(s.models[0].promptTokens, 90);
});

test("LlmTokenRuntime: tick pulls observations via orderedSnapshots and route registers", () => {
  const ledger = tmpLedger();
  let ticks = 0;
  let cleared = 0;
  const timers = [];
  const runtime = createLlmTokenRuntime({
    ledger,
    orderedSnapshots: () => {
      ticks++;
      return [
        {
          id: "spark-a",
          llmPorts: [8888],
          metrics: { llm: [{ available: true, modelId: "org/a", totalOutputTokens: 10 + ticks * 5, totalPromptTokens: 100 }] },
        },
      ];
    },
    now: () => 1_730_000_000_000,
    setIntervalFn: (fn, ms) => {
      timers.push(fn);
      return timers.length;
    },
    clearIntervalFn: () => {
      cleared++;
    },
  });

  assert.equal(runtime.start(), true);
  assert.equal(runtime.start(), false); // idempotent
  assert.equal(ticks, 1); // immediate first tick
  assert.equal(timers.length, 1);
  timers[0](); // manual tick
  assert.equal(ticks, 2);
  assert.equal(runtime.stop(), true);
  assert.equal(cleared, 1);

  const s = ledger.snapshot().series[0];
  assert.equal(s.models[0].completionTokens, 5); // second tick: 20 - 15

  const routes = [];
  const app = { get: (p, h) => routes.push({ p, h }), delete: () => {} };
  registerLlmTokenTotalsRoute(app, ledger);
  assert.deepEqual(routes.map((r) => r.p), ["/api/llm-token-totals/history", "/api/llm-token-totals"]);
  let sent = null;
  routes[1].h({}, { json: (v) => (sent = v) });
  assert.equal(sent.series[0].sparkId, "spark-a");
  let hist = null;
  routes[0].h({}, { json: (v) => (hist = v) });
  assert.ok(Array.isArray(hist.day) && Array.isArray(hist.hour));
});

test("LlmTokenLedger.history: day and hour rows carry the same credited deltas, oldest first", () => {
  const ledger = tmpLedger();
  const obs = (output, prompt, cached) => [
    { sparkId: "s1", port: 8888, modelId: "m/a", output, prompt, cached },
  ];
  const t0 = Date.UTC(2026, 9, 6, 23, 50); // 23:50 UTC on Oct 6
  ledger.record(obs(100, 1000, 200), t0); // baseline only
  ledger.record(obs(150, 1500, 400), t0 + 5 * 60_000); // 23:55 -> Oct 6 / hour 23
  ledger.record(obs(170, 1600, 400), t0 + 20 * 60_000); // 00:10 -> Oct 7 / hour 00
  const h = ledger.history(t0 + 30 * 60_000);
  assert.deepEqual(h.day.map((r) => [r.t, r.completionTokens, r.promptTokens, r.cachedTokens]), [
    ["2026-10-06", 50, 500, 200],
    ["2026-10-07", 20, 100, 0],
  ]);
  assert.deepEqual(h.hour.map((r) => r.t), ["2026-10-06T23", "2026-10-07T00"]);
  assert.equal(h.firstDay, "2026-10-06");
  assert.equal(h.retention.hours, 72);
  assert.equal(h.day[0].sparkId, "s1");
  assert.equal(h.day[0].port, 8888);
});

test("LlmTokenLedger: hourly buckets are pruned to 72 hours and survive a save/load round trip", () => {
  const ledger = tmpLedger();
  const base = Date.UTC(2026, 0, 1, 0, 0);
  let out = 0;
  ledger.record([{ sparkId: "s1", port: 1, modelId: "m", output: out, prompt: 0, cached: 0 }], base);
  for (let h = 1; h <= 100; h++) {
    out += 10;
    ledger.record([{ sparkId: "s1", port: 1, modelId: "m", output: out, prompt: 0, cached: 0 }], base + h * 3_600_000);
  }
  const hours = ledger.history(base + 100 * 3_600_000).hour;
  assert.equal(hours.length, 72);
  assert.equal(hours.at(-1).completionTokens, 10);
  ledger.flush();
  const reloaded = new LlmTokenLedger(ledger.filePath);
  assert.equal(reloaded.history().hour.length, 72);
});

test("reset() zeroes totals and history, per Spark or for all, and keeps counter baselines", () => {
  const ledger = tmpLedger();
  const t0 = Date.UTC(2026, 8, 1, 10, 0, 0);
  ledger.record([obs("a", 8000, "m1", 100, 1000), obs("b", 8000, "m2", 50, 500)], t0);
  ledger.record([obs("a", 8000, "m1", 160, 1400), obs("b", 8000, "m2", 80, 700)], t0 + 15_000);
  const total = (id) => ledger.snapshot("all").series.find((s) => s.sparkId === id)?.models.reduce((n, m) => n + m.completionTokens, 0) ?? 0;
  assert.equal(total("a"), 60);
  assert.equal(total("b"), 30);
  assert.equal(ledger.reset({ sparkId: "a" }), 1);
  assert.equal(total("a"), 0);
  assert.equal(total("b"), 30, "other Sparks are untouched");
  // The engine counter kept its baseline: only the new 40 tokens are credited, not all 200.
  ledger.record([obs("a", 8000, "m1", 200, 1500)], t0 + 30_000);
  assert.equal(total("a"), 40);
  assert.equal(ledger.reset(), 2);
  assert.equal(total("b"), 0);
  assert.equal(ledger.reset(), 0);
});
