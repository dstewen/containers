import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = path.resolve(__dirname, "..");

// ─── Spark config file path ──────────────────────────────
const SPARKS_JSON_PATH = process.env.SPARKS_JSON_PATH || path.join(ROOT, "config", "sparks.json");
const GPU_MEMORY_JSON_PATH =
  process.env.GPU_MEMORY_JSON_PATH || path.join(ROOT, "config", "gpu-memory.json");
/** Encrypted SSH password store (never served by API; lives on config volume). */
const SPARKS_SECRETS_PATH =
  process.env.SPARKS_SECRETS_PATH || path.join(ROOT, "config", "sparks-secrets.json");
/** AES key file (auto-generated if SPARKDASH_SECRETS_KEY unset). */
const SECRETS_KEY_PATH =
  process.env.SECRETS_KEY_PATH || path.join(ROOT, "config", ".secrets-key");
/** Daily LLM tok/s rollups (gitignored). */
const LLM_DAILY_JSON_PATH =
  process.env.LLM_DAILY_JSON_PATH || path.join(ROOT, "config", "llm-daily.json");
/** Cumulative LLM token totals per model (gitignored). */
const LLM_TOKEN_JSON_PATH =
  process.env.LLM_TOKEN_JSON_PATH || path.join(ROOT, "config", "llm-token-totals.json");
/** Rolling fleet energy estimates (gitignored; written atomically at mode 0600). */
const FLEET_ENERGY_JSON_PATH =
  process.env.FLEET_ENERGY_JSON_PATH || path.join(ROOT, "config", "fleet-energy.json");
/** Permanent monthly energy roll-up (gitignored; survives resets and fleet changes). */
const FLEET_ENERGY_MONTHLY_JSON_PATH =
  process.env.FLEET_ENERGY_MONTHLY_JSON_PATH || path.join(ROOT, "config", "fleet-energy-monthly.json");

// ─── LLM / Comfy probe timeouts ──────────────────────────
const LLM_PROBE_TIMEOUT_MS = 3000;
const COMFY_PROBE_TIMEOUT_MS = parseInt(process.env.COMFY_PROBE_TIMEOUT_MS || "3000", 10);
const TAILSCALE_PROBE_TIMEOUT_MS = parseInt(process.env.TAILSCALE_PROBE_TIMEOUT_MS || "8000", 10);
const SSH_CONNECT_TIMEOUT = 5; // seconds
// Reuse one authenticated SSH connection per Spark instead of dialing a new one
// for every collector tick. Set SSH_MULTIPLEX=0 to go back to one connection
// per command (e.g. an sshd with `MaxSessions 1`).
const SSH_MULTIPLEX = process.env.SSH_MULTIPLEX !== "0";

// ─── Poll intervals (milliseconds) ───────────────────────
// The fast domains (GPU, CPU/RAM, network, LLM, ComfyUI, bandwidth) follow
// Settings → Poll interval (see resolveFastPollIntervals below); the constants
// here are their values when no setting is passed. Setting one of their env
// vars pins that domain regardless of the setting.
const POLL_INTERVAL_GPU = parseInt(process.env.POLL_INTERVAL_GPU || "2000", 10);
const POLL_INTERVAL_CPU = parseInt(process.env.POLL_INTERVAL_CPU || "2000", 10);
const POLL_INTERVAL_NETWORK = parseInt(process.env.POLL_INTERVAL_NETWORK || "2000", 10);
const POLL_INTERVAL_STORAGE = parseInt(process.env.POLL_INTERVAL_STORAGE || "5000", 10);
const POLL_INTERVAL_LLM = parseInt(process.env.POLL_INTERVAL_LLM || "2000", 10);
const POLL_INTERVAL_COMFY = parseInt(process.env.POLL_INTERVAL_COMFY || "2000", 10);
// Tailnet membership changes slowly; each poll is an SSH round-trip.
const POLL_INTERVAL_TAILSCALE = parseInt(process.env.POLL_INTERVAL_TAILSCALE || "30000", 10);
// Kernel journal scan for NV_ERR_NO_MEMORY — not on the 2s GPU loop.
const POLL_INTERVAL_NVERR = parseInt(process.env.POLL_INTERVAL_NVERR || "60000", 10);
// dmon -c 1 -d 1 blocks ~1s; default 2s avoids stacking with in-flight guards
const POLL_INTERVAL_BANDWIDTH = parseInt(process.env.POLL_INTERVAL_BANDWIDTH || "2000", 10);
// Dedicated liveness (sshTest / local ping) cadence — not a metric domain.
const POLL_INTERVAL_LIVENESS = parseInt(process.env.POLL_INTERVAL_LIVENESS || "5000", 10);
// Hermes Agent update check cadence. `hermes update --check` runs `git fetch`
// on the target every time, so keep it slow (default 10 min).
const POLL_INTERVAL_HERMES = parseInt(process.env.POLL_INTERVAL_HERMES || "600000", 10);
// Hard cap while running `hermes update` over SSH (repo pull + dep reinstall).
const HERMES_UPDATE_TIMEOUT_MS = parseInt(
  process.env.HERMES_UPDATE_TIMEOUT_MS || "600000",
  10
);

/**
 * `nvidia-smi dmon -c 1 -d 1` blocks ~1 s, so the bandwidth domain never
 * follows the poll interval below 2 s — a 1 s cadence would stack each sample
 * onto the previous one's in-flight guard and silently halve the rate.
 */
const BANDWIDTH_MIN_INTERVAL_MS = 2000;

/** Fallback when no (or an invalid) poll interval setting is supplied. */
const DEFAULT_FAST_POLL_INTERVAL_MS = 2000;

/**
 * Collector domain → env var that pins it. RAM has always shared the CPU var.
 * "memory" is the unified-memory/bandwidth domain (dmon).
 */
const FAST_POLL_ENV_VARS = Object.freeze({
  gpu: "POLL_INTERVAL_GPU",
  cpu: "POLL_INTERVAL_CPU",
  ram: "POLL_INTERVAL_CPU",
  network: "POLL_INTERVAL_NETWORK",
  memory: "POLL_INTERVAL_BANDWIDTH",
  llm: "POLL_INTERVAL_LLM",
  comfy: "POLL_INTERVAL_COMFY",
});

/** Positive integer ms from an env value, or null when unset/blank/invalid. */
function envIntervalMs(raw) {
  if (raw == null || String(raw).trim() === "") return null;
  const n = parseInt(String(raw), 10);
  return Number.isFinite(n) && n > 0 ? n : null;
}

/**
 * Env overrides as they were when the server started — read at import time,
 * like every other constant in this file, so the precedence cannot shift
 * under a running server.
 */
const FAST_POLL_ENV_OVERRIDES = Object.freeze(
  Object.fromEntries(
    Object.entries(FAST_POLL_ENV_VARS).map(([domain, name]) => [
      domain,
      envIntervalMs(process.env[name]),
    ])
  )
);

/**
 * Per-domain intervals for the fast collectors.
 *
 * Precedence, per domain: an explicitly set env var (POLL_INTERVAL_GPU, …)
 * wins; otherwise the Settings poll interval applies. The bandwidth domain is
 * floored at BANDWIDTH_MIN_INTERVAL_MS when it follows the setting.
 *
 * @param {number} [pollIntervalMs] Settings → Poll interval
 * @param {Record<string, number | null>} [overrides] domain → pinned ms (env)
 * @returns {{ gpu: number, cpu: number, ram: number, network: number, memory: number, llm: number, comfy: number }}
 */
function resolveFastPollIntervals(pollIntervalMs, overrides = FAST_POLL_ENV_OVERRIDES) {
  const base =
    typeof pollIntervalMs === "number" && Number.isFinite(pollIntervalMs) && pollIntervalMs > 0
      ? Math.round(pollIntervalMs)
      : DEFAULT_FAST_POLL_INTERVAL_MS;
  const out = {};
  for (const domain of Object.keys(FAST_POLL_ENV_VARS)) {
    const pinned = overrides?.[domain];
    if (typeof pinned === "number" && Number.isFinite(pinned) && pinned > 0) {
      out[domain] = pinned;
    } else {
      out[domain] = domain === "memory" ? Math.max(BANDWIDTH_MIN_INTERVAL_MS, base) : base;
    }
  }
  return /** @type {any} */ (out);
}

// ─── Port ────────────────────────────────────────────────
const PORT = parseInt(process.env.PORT || "5555", 10);
const LLM_PORT = parseInt(process.env.LLM_PORT || "8888", 10);
/** Default ComfyUI HTTP port. */
const COMFY_PORT = parseInt(process.env.COMFY_PORT || "8188", 10);

// ─── DGX Spark constants ────────────────────────────────
const DGX_SPARK = {
  TOTAL_POWER_W: 250,
  CPU_TDP_W: 65,
  GPU_POWER_W: 100,
  MEMORY_HBM_SIZE_GB: 128,
  MEMORY_PEAK_BANDWIDTH_GBPS: 400,
  THERMAL_THRESHOLDS: {
    junction: { warning: 85, critical: 95 },
    memory: { warning: 75, critical: 85 },
    pcb: { warning: 65, critical: 75 },
  },
  FAN_RPM_WARNING: 4000,
  FAN_RPM_CRITICAL: 5000,
};

// ─── Unit conversions ───────────────────────────────────
const UNIT_CONVERSION = {
  BYTES_TO_MB: 1024 * 1024,
  BYTES_TO_GB: 1024 * 1024 * 1024,
  MICRO_TO_WATT: 1e6,
  MILLI_TO_SEC: 1000,
};

// ─── Hardware defaults ───────────────────────────────────
const HARDWARE_DEFAULTS = {
  CPU_TDP_FALLBACK: 185,
};

// ─── Host paths for Docker bind mounts ───────────────────
const HOST_PATHS = {
  PROC: process.env.HOST_PROC_PATH || "/host/proc",
  SYS: process.env.HOST_SYS_PATH || "/host/sys",
  ROOT: process.env.HOST_ROOT_PATH || "/host/root",
};

export {
  SPARKS_JSON_PATH,
  GPU_MEMORY_JSON_PATH,
  SPARKS_SECRETS_PATH,
  SECRETS_KEY_PATH,
  LLM_DAILY_JSON_PATH,
  LLM_TOKEN_JSON_PATH,
  FLEET_ENERGY_JSON_PATH,
  FLEET_ENERGY_MONTHLY_JSON_PATH,
  LLM_PROBE_TIMEOUT_MS,
  COMFY_PROBE_TIMEOUT_MS,
  TAILSCALE_PROBE_TIMEOUT_MS,
  SSH_CONNECT_TIMEOUT,
  SSH_MULTIPLEX,
  POLL_INTERVAL_GPU,
  POLL_INTERVAL_CPU,
  POLL_INTERVAL_NETWORK,
  POLL_INTERVAL_STORAGE,
  POLL_INTERVAL_LLM,
  POLL_INTERVAL_COMFY,
  POLL_INTERVAL_TAILSCALE,
  POLL_INTERVAL_NVERR,
  POLL_INTERVAL_BANDWIDTH,
  POLL_INTERVAL_LIVENESS,
  POLL_INTERVAL_HERMES,
  BANDWIDTH_MIN_INTERVAL_MS,
  FAST_POLL_ENV_VARS,
  FAST_POLL_ENV_OVERRIDES,
  resolveFastPollIntervals,
  HERMES_UPDATE_TIMEOUT_MS,
  PORT,
  LLM_PORT,
  COMFY_PORT,
  DGX_SPARK,
  UNIT_CONVERSION,
  HARDWARE_DEFAULTS,
  HOST_PATHS,
  ROOT,
};
