import { describe, expect, it, vi } from "vitest";
import { FleetEnergyCard } from "./FleetEnergyCard";
import { flush, render } from "../../testing/render";
import type { FleetEnergy } from "../../api/types";

vi.mock("../../api/client", () => ({
  fetchFleetEnergy: vi.fn(),
  fetchRestartAvailable: vi.fn().mockResolvedValue({ available: false }),
  restartServer: vi.fn(),
}));

import { fetchFleetEnergy } from "../../api/client";

const fetchEnergy = vi.mocked(fetchFleetEnergy);

function energy(overrides: Partial<FleetEnergy> = {}): FleetEnergy {
  return {
    estimated: true,
    membershipChanged: false,
    restartRequired: false,
    trackedNodeIds: ["a", "b"],
    currentNodeIds: ["a", "b"],
    freshNodeCount: 2,
    currentWatts30s: 240,
    energy24hKwh: 1.5,
    energy31dKwh: 40,
    whPerOutputToken24h: 0.0123,
    outputTokens24h: 100,
    coverage24hMs: 86_400_000,
    coverage24hWindowMs: 86_400_000,
    coverage31dMs: 0,
    coverage31dWindowMs: 86_400_000 * 31,
    nodeCoverage24hMs: {},
    nodeCoverage31dMs: {},
    hourlyWatts24h: Array.from({ length: 24 }, (_, hour) => (hour % 4 === 0 ? null : 100 + hour)),
    ...overrides,
  };
}

describe("FleetEnergyCard states", () => {
  it("labels estimated values and keeps hourly gaps empty", async () => {
    fetchEnergy.mockResolvedValue(energy());
    const { container } = render(<FleetEnergyCard nodeCount={2} />);
    await flush();
    expect(container.textContent).toContain("Estimated, not wall-metered");
    // coverage24hMs is full-fleet wall-clock coverage capped at DAY_MS, so a
    // full window must read 100.0% regardless of node count.
    expect(container.textContent).toContain("24h coverage 100.0%");
    expect(container.textContent).toContain("240 W");
    expect(container.textContent).toContain("0.0123 Wh/token");
    const bars = [...container.querySelectorAll("[aria-label] span")];
    expect(bars.filter((bar) => (bar as HTMLElement).style.height === "0px" || (bar as HTMLElement).style.height === "0")).toHaveLength(6);
  });

  it("shows a fleet-scale efficiency to three significant digits", async () => {
    // ~8 kWh over ~7.6M output tokens: fixed 4-decimal formatting rounded
    // this to 0.0011, and a busier day to a single digit.
    fetchEnergy.mockResolvedValue(energy({ whPerOutputToken24h: 0.0010537 }));
    const { container } = render(<FleetEnergyCard nodeCount={2} />);
    await flush();
    expect(container.textContent).toContain("0.00105 Wh/token");
  });

  it("never switches a large efficiency to exponent notation", async () => {
    // A nearly idle fleet that served a handful of tokens.
    fetchEnergy.mockResolvedValue(energy({ whPerOutputToken24h: 2403.7 }));
    const { container } = render(<FleetEnergyCard nodeCount={2} />);
    await flush();
    expect(container.textContent).toContain("2404 Wh/token");
  });

  it("reads coverage from the server-provided window, independent of fleet size", async () => {
    // Full fleet wall-clock coverage over the server's window is 100% at any
    // node count — the window is time, not node-time.
    for (const nodeCount of [1, 2, 32]) {
      fetchEnergy.mockResolvedValue(
        energy({ freshNodeCount: nodeCount, currentNodeIds: Array.from({ length: nodeCount }, (_, i) => `n${i}`), trackedNodeIds: Array.from({ length: nodeCount }, (_, i) => `n${i}`) })
      );
      const { container } = render(<FleetEnergyCard nodeCount={nodeCount} />);
      await flush();
      expect(container.textContent).toContain("24h coverage 100.0%");
    }
    // Half the window reads 50% at any fleet size too.
    fetchEnergy.mockResolvedValue(energy({ coverage24hMs: 43_200_000 }));
    const three = render(<FleetEnergyCard nodeCount={3} />);
    await flush();
    expect(three.container.textContent).toContain("24h coverage 50.0%");
    // Older servers without coverage24hWindowMs fall back to the 24h window.
    fetchEnergy.mockResolvedValue(energy({ coverage24hWindowMs: undefined }));
    const legacy = render(<FleetEnergyCard nodeCount={2} />);
    await flush();
    expect(legacy.container.textContent).toContain("24h coverage 100.0%");
  });

  it("explains empty, partial, membership-changed, and fetch-error states", async () => {
    fetchEnergy.mockResolvedValue(energy({ energy24hKwh: null, currentWatts30s: null }));
    const warming = render(<FleetEnergyCard nodeCount={2} />);
    await flush();
    expect(warming.container.textContent).toContain("Warming up");

    fetchEnergy.mockResolvedValue(energy({ freshNodeCount: 1 }));
    const partial = render(<FleetEnergyCard nodeCount={2} />);
    await flush();
    expect(partial.container.textContent).toContain("Partial coverage: 1/2");

    fetchEnergy.mockResolvedValue(energy({ freshNodeCount: 1, staleNodeIds: ["b"] }));
    const named = render(<FleetEnergyCard nodeCount={2} nodeNames={{ b: "Spark B" }} />);
    await flush();
    expect(named.container.querySelector(".ov-help")?.getAttribute("title")).toContain("No fresh reading from: Spark B");

    fetchEnergy.mockResolvedValue(energy({ membershipChanged: true, restartRequired: true }));
    const membership = render(<FleetEnergyCard nodeCount={2} />);
    await flush();
    expect(membership.container.textContent).toContain("Restart sparkDash");

    fetchEnergy.mockRejectedValue(new Error("disk write failed"));
    const failed = render(<FleetEnergyCard nodeCount={2} />);
    await flush();
    expect(failed.container.textContent).toContain("Energy telemetry unavailable: disk write failed");
  });
});
